/*
This program is a tool kit with multiple functions for parsing a text file
Functions include:
-Sorting the file (using merge sort)
-Searching the file
-Copying out sections from the file starting at selected words
-Removing all repeated chars/words
-Length of file

Main must be provided to use the functions

Jeremy Thorne
thornej@uoguelph.ca
*/
#include "text.h"

struct node_struct *txt2words(FILE *fp){
    char *line, *temp;  
    struct node_struct *head;
    struct node_struct **current;

    /*sets up head pointer like we learned in class*/
    current = &head;
    
    /*loops through until end of file*/
    while(!feof(fp)){
        /*mallocs for max size of 256 and gets in line from file*/
        line = malloc(sizeof(char*) * 256);
        fgets(line, 256, fp); 
        temp = line;/*temp pointer for freeing later*/
        /*this gets rid of newlines on lines that have more than just a newline*/
        if(strlen(line) > 1){
            strtok(line, "\r\n");
        }
        /*creates new node in list and adds word returned by get_word*/
        while(strlen(line) != 0){
            (*current) = malloc(sizeof(struct node_struct));
            (*current)->data = get_word(&line);
            current = &((*current)->next);
        }
        /*frees the line*/
        free(temp);    
    }
    /*sets last nodes next to NULL*/
    *current = NULL;
    return head;
}

char* get_word(char** strPtr){
    char* output;  
    int i = 0;
    int j = 0;
    int wordType = -1;

    output = malloc(sizeof(char*));
    /*skips spaces and non-printable characters*/
    if(strPtr[0][i] == ' ' || !isprint(strPtr[0][i])){
        *strPtr += sizeof(strPtr[0][i]);
    }

    /*word type identifier*/
    if(isalnum(strPtr[0][i])){
        wordType = 1;
    }
    else if(strPtr[0][i] == '\n'){
        wordType = 3;
    }
    else{
        wordType = 2;
    }

    if(wordType == 1){
        /*while loop the get size of word and properly malloc output*/
        while(isalnum(strPtr[0][i]) != 0 || (strPtr[0][i] == '\'' && strPtr[0][i+1] != '\'') || (strPtr[0][i] == '-' && strPtr[0][i+1] != '-') ){
            i++;            
            output = realloc(output,sizeof(char*) * i); 
        }
        /*copying the word into the output*/
        for(j = 0; j < i; j++){
            output[j] = strPtr[0][j];
        }
        /*moving pointer so it removes the word from the input string*/
        *strPtr += sizeof(char) * i;
    }
    else if(wordType == 2){
        /*while loop the get size of word and properly malloc output*/
        while(strPtr[0][i] == strPtr[0][i+1]){
            i++;
            output = realloc(output,sizeof(char*) * i); 
        }
        /*copies word char by char to output*/
        for(j = 0; j < i+1; j++){
            output[j] = strPtr[0][j];
        }
        /*moving pointer so it removes the word from the input string*/
        *strPtr += sizeof(char) * (i+1);
    }
    else if(wordType == 3){
        *strPtr += sizeof(char);
        return output;
    }
    return output;
}

void ftext( FILE *fp, struct node_struct *list ){
    int currentLineLen = 0;
    while(list){
        /*checks to see if adding the word will go over 80 chars*/
        if ((currentLineLen + strlen(list->data) + 1) > 79){
            fprintf(fp,"\n");
            currentLineLen = 0;
        } else {
            currentLineLen += strlen(list->data) + 1;
            fprintf(fp,"%s ", (char*)list->data);
            
        }
        
        list = list->next;
    }
    /*just adding a newline for nicer output*/
    fprintf(fp,"\n");
}

struct node_struct *search( struct node_struct *list, char *target, int (*compar)(const void *, const void *) ){
    struct node_struct *head;
    struct node_struct **found;
    /*same way of creating list as all other functions*/
    found = &head;
    while(list){
        /*if data = target adds new node that points to the original data*/
        if(compar(list->data, target) == 0){
            *found = malloc(sizeof (struct node_struct));
            (*found)->data = &(list->data);
            found = &((*found)->next);
        }
        list = list->next;
    }
    *found = NULL;
    return head;
}

struct node_struct *copy( struct node_struct *start, struct node_struct *end ){
    struct node_struct *head;
    struct node_struct **copy;

    copy = &head;
    /*same linked list creation as other functions
      copies all data from start positon until end*/
    while (start){
        if (start == end){
            break;
        }
        *copy = malloc(sizeof(struct node_struct));
        (*copy)->data = start->data;
        copy = &((*copy)->next);
        start = start->next;
    }
    *copy = NULL;
    return head;
}

struct node_struct *sort( struct node_struct *list, int (*compar)(const void *, const void *) ){
    /*wanted to use a double pointer to make the recursion easier
      but since we cant change parameters i had to do this*/
    doubleSort(&list);
    return list;
}

void doubleSort(struct node_struct **list){
    /*recursive function for sorting the linked list*/
    struct node_struct *bottomHalf;
    if ((*list) == NULL || (*list)->next == NULL){
        return;
    }

    /*stores top half of list in list and bottom half in bottomHalf*/
    bottomHalf = split(list);

    /*recursive call on top and bottom halfs of list*/
    doubleSort(list);
    doubleSort(&bottomHalf);

    /*combines lists together and stores in list*/
    *list = combine(*list, bottomHalf, strcmpvoid);
}

struct node_struct* split(struct node_struct **input){
    struct node_struct *length = *input;
    struct node_struct *bottomHalf;
    struct node_struct *firstHalf;
    int i = 0;

    /*gets length of list so we can split in middle*/
    int count = 0;
    while(length){
        count++;
        length = length->next;
    }
    length = *input;

    /*tracks through list until middle */
    for(i = 0; i < (count/2) - 1; i++){
        length = length->next;
    }

    /*sets up first half final node with NULL and sets bottom half to node that was attached to that one*/
    firstHalf = length;
    length = length->next;
    firstHalf->next = NULL;
    bottomHalf = length;

    return bottomHalf;

}

struct node_struct *combine(struct node_struct *list1, struct node_struct *list2, int (*compar)(const void *, const void *)){
    struct node_struct *out; 

    if (list1 == NULL){
        return list2;
    } else if (list2 == NULL){
        return list1;
    }

    /*recursive function for combining lists back together
      uses strcmpvoid for comparing data elements*/
    if (compar(list1->data, list2->data) <= 0){
        out = list1;
        out->next = combine(list1->next, list2, strcmpvoid);
    } else {
        out = list2;
        out->next = combine(list1, list2->next, strcmpvoid);
    }
    return out;
}

void remove_repeats (struct node_struct *list, int (*compar)(const void *, const void *)){
    struct node_struct *temp;
    /*loops through whole list and if current data = next node data skips sets current nodes next to next->next*/
    while(list){
        if(compar(list->data, list->next->data) == 0){
            temp = list->next->next;
            free(list->next); /*frees duplicate node*/
            list->next = temp;
        } else {
            list = list->next; 
        }    
    }
}

int length( struct node_struct *list ){
    int length = 0;
    /*loops through list and keeps track of how many nodes*/
    while(list){
        length++;
        list = list->next;
    }
    return length;
}

void free_list( struct node_struct *list, int free_data ){
    struct node_struct *current;
    /*frees nodes and data based on free_data flag*/
    if (free_data == 0) {
        while(list){
            current = list;
            list = list->next;  
            free(current);
        }
    } else {
        while(list){
            current = list;
            list = list->next;
            free(current->data);
            free(current);
        }        
    }
}

int strcmpvoid(const void *a, const void *b){
    char *ptr_a;
    char *ptr_b;

    ptr_a = (char*)a;
    ptr_b = (char*)b;

    return strcmp(ptr_a, ptr_b);
}