/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
*/
#include "common.h"
#include "binary.h"
#include "title.h"


void add_node(struct tree_node **root, char* title, void *element){
    if (*root) {

        if (strcmp(title, (*root)->key) > 0) {
            add_node( &((*root)->left), title, element);
        } else {
            add_node( &((*root)->right), title, element);
        }
        
    } else {
        (*root) = malloc( sizeof(struct tree_node));
        (*root)->data = element;
        (*root)->key = title;
        (*root)->left = NULL;
        (*root)->right = NULL;
    }
}

struct tree_node *find_node(struct tree_node *root, char* data){
    /*loops through tree until node is found*/
    if (root) {
        if (strcmp(data, root->key) == 0) {
            return root;
        } else {
            if (strcmp(data, root->key) > 0) {
                return find_node(root->left, data);
            } else {
                return find_node(root->right, data);
            }
        }
    } else {
        return NULL;
    }
}

void free_node(struct tree_node *root) {
    /*like we did in class frees all children of root node*/
    if (root) {
        free_node(root->left);
        free_node(root->right);
        free(root);
    }
}