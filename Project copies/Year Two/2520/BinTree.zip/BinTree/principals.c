/**
 * Jeremy Thorne
 * thornej@uoguelph.ca
*/
#include "common.h"
#include "principals.h"
#include "binary.h"

struct principals_data *get_principals(char* path){
    char *line;
    char *col;
    char *nconst;
    char *tconst;
    int count = 0;
    char exten[50] = "/title.principals.tsv";
    char *filePath;
    struct title_principals *structAr;
    struct principals_data *data;

    FILE *fp;
    filePath = malloc((sizeof(char) * strlen(path)) + (sizeof(char) * strlen(exten) ));
    strcpy(filePath, path);
    strcat(filePath, exten);
    fp = fopen(filePath, "r");
    free(filePath);

    line = malloc(sizeof(char*) * 1000);
    while(!feof(fp)){
        fgets(line, 1000, fp);
        col = get_col(line, 4);
        /*counts all rows with actor or actress*/
        if(strstr(col, "actor") || strstr(col, "actress")){
            count++;
        }
    }
    /*mallocs for data struct and struct array*/
    data = malloc(sizeof(struct principals_data));
    data->length = count;
    structAr = malloc(sizeof(struct title_principals) * count);
    fseek(fp, 0, SEEK_SET);
    count = 0;

    while(!feof(fp)){
        fgets(line, 1000, fp);
        col = get_col(line, 4);
        /*adds all rows containing actor and actress to the array*/
        if(strstr(col, "actor") || strstr(col, "actress")){
            tconst = get_col(line, 1);
            reverse(tconst);
            nconst = get_col(line, 3);
            reverse(nconst);
            structAr[count].tconst = tconst;
            structAr[count].nconst = nconst;
            structAr[count].characters = get_col(line, 6);
            count++;
        }
    }

    free(line);
    fclose(fp);

    data->arrAdd = structAr;
    data->root1 = 0;
    data->root2 = 0;
    return data;
}

void build_pindex_nconst(struct principals_data *data){
    int i;
    for (i = 0; i < data->length; i++){
        add_node(&(data->root1), data->arrAdd[i].nconst, data->arrAdd + i);
    }
}

struct title_principals *find_nconst_principals(struct principals_data *data, char* nconst){
    struct tree_node *node = NULL;
    struct title_principals *out = NULL;

    node = find_node(data->root1, nconst);

    if (node == NULL){
        printf("nothing found\n");
        exit(0);
    }

    out = node->data;

    return out;
}

void build_pindex_tconst(struct principals_data *data){
    int i;
    for (i = 0; i < data->length; i++){
        add_node(&(data->root2), data->arrAdd[i].tconst, data->arrAdd + i);
    }
}

struct title_principals *find_tconst_principals(struct principals_data *data, char* tconst){
    struct tree_node *node = NULL;
    struct title_principals *out = NULL;

    node = find_node(data->root2, tconst);

    if (node == NULL){
        printf("nothing found\n");
        exit(0);
    }

    out = node->data;

    return out;
}