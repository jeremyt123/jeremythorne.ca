/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
*/
struct title_principals{
    char *tconst;
    char *nconst;
    char *characters;
};

struct principals_data *get_principals(char* path);
void build_pindex_nconst(struct principals_data *data);
struct title_principals *find_nconst_principals(struct principals_data *data, char* nconst);
void build_pindex_tconst(struct principals_data *data);
struct title_principals *find_tconst_principals(struct principals_data *data, char* tconst);

