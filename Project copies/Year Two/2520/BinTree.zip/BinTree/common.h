/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct tree_node{
    char *key;
    void *data;
    struct tree_node *left;
    struct tree_node *right;
};

struct title_data{
    int length;
    struct title_basics *arrAdd;
    struct tree_node *root1;
    struct tree_node *root2;
};

struct name_data{
    int length;
    struct name_basics *arrAdd;
    struct tree_node *root1;
    struct tree_node *root2;
};

struct principals_data{
    int length;
    struct title_principals *arrAdd;
    struct tree_node *root1;
    struct tree_node *root2;
};

char* get_col(char*, int);
void reverse(char* input);