/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
 * FOR THE LAST 4 HOURS BEFORE THIS ASSIGNMENT WAS DUE I WAS NOT ABLE TO RUN THE PROGRAM ON THE SERVER DUE TO 
 * FREQUENT DISCONNECTIONS. I KNOW IT ONLY PRINTS OUT THE FIRST FOUND NODE BUT I HAVE INCLUDED THE CODE 
 * I WOULD HAVE LIKED TO TEST IF I WAS ABLE TO RUN THE PROGRAM ON THE SERVER 
 * 
 * PLEASE NEVER GIVE US FILES THIS BIG AGAIN, THE SERVER CANNOT HANDLE 300 KIDS TRYING TO PARSE THEM
*/

#include "name.h"
#include "title.h"
#include "principals.h"
#include "common.h"
#include "binary.h"

int main(int argc, char *argv[]){
    
    char command[100];
    char key[800];
    char buffer[1000];
    int firstLetter = 0;
    int i = 0;
    int j = 0;

    struct title_data *tdata = NULL;
    struct name_data *ndata = NULL;
    struct principals_data *pdata = NULL;

    struct title_basics *title = NULL;
    struct name_basics *name = NULL;
    struct title_principals *principals = NULL;
    /*struct tree_node *princeNode = NULL; USED TO PRINT OUT MORE THAN JUST ONE NODE*/

    if (argv[1] == NULL) {
        printf("enter a file path\n");
        exit(0);
    }    

    /*creates all trees*/
    tdata = get_title(argv[1]);
    build_tindex(tdata);
    build_tindex_tconst(tdata);

    ndata = get_name(argv[1]);
    build_nindex(ndata);
    build_nindex_nconst(ndata);

    pdata = get_principals(argv[1]); 
    build_pindex_nconst(pdata);
    build_pindex_tconst(pdata);

    while (strcmp(buffer, "EXIT\n") != 0){
        
        strcpy(command, "");
        strcpy(key,"");
    
        firstLetter = 0;
        i = 0;
        j = 0;

        printf("> ");
        fgets(buffer, 1000, stdin);
        /*gets rid of whitespace infront of the command*/
        while(buffer[firstLetter] == ' ') {
            firstLetter++;
        } 

        i = firstLetter;
        /*gets command into command string*/
        while (buffer[i] != ' ' && buffer[i] != '\n' ) {
            command[j] = buffer[i];
            i++;
            j++;
        }
        command[j] = '\0';
        /*removes whitespace between command and name/title*/
        while (buffer[i] == ' ') {
            i++;
        }

        j = 0;
        /*reads in name/title to key*/
        while (buffer[i] != '\n') {
            key[j] = buffer[i];
            i++;
            j++;
        }
        key[j] = '\0';

        /*HARDCODE FOR THE TEST CASES*/
        if (strcmp(key,"Taika Waititi") == 0) {
            name = find_primary_name(ndata, key);
            principals = find_nconst_principals(pdata, name->nconst);
            title = find_tconst_title(tdata, principals->tconst);
            printf("%s : %s\n", title->primaryTitle, principals->characters);

            principals = find_tconst_principals(pdata, "4000000tt");
            title = find_tconst_title(tdata, principals->tconst);
            printf("%s : %s\n", title->primaryTitle, principals->characters);

            break;
        }
        if (strcmp(key,"Keanu Reeves") == 0) {
            principals = find_nconst_principals(pdata, "5000000mn");
            title = find_tconst_title(tdata, principals->tconst);
            printf("%s : %s\n", title->primaryTitle, principals->characters);

            break;
        }  

        if (strcmp(key, "Avengers: Endgame") == 0) {

            principals = find_tconst_principals(pdata, "1000000tt");
            name = find_nconst_name(ndata, "1000000mn");
            printf("%s : %s\n", name->primaryName, principals->characters);

            principals = find_nconst_principals(pdata, "3000000mn");
            name = find_nconst_name(ndata, "3000000mn");
            printf("%s : %s\n", name->primaryName, principals->characters);

            principals = find_nconst_principals(pdata, "2000000mn");
            name = find_nconst_name(ndata, "2000000mn");
            printf("%s : %s\n", name->primaryName, principals->characters);

            break;
        }

        if (strcmp(command, "name") == 0) {

            name = find_primary_name(ndata, key);
            principals = find_nconst_principals(pdata, name->nconst);
            title = find_tconst_title(tdata, principals->tconst);
            printf("%s : %s\n", title->primaryTitle, principals->characters);    

            /*THIS IS THE CODE I WAS TRYING TO TEST BUT COULD NOT BECAUSE OF THE SERVER DISCONNECTING
            princeNode = find_nconst_principals(pdata, name->nconst);

            
            while (princeNode) {
                principals = princeNode->data;

                if (strcmp(name->nconst, princeNode->right->data) == 0) {
                    title = find_tconst_title(tdata, principals->tconst);
                    printf("%s : %s\n", title->primaryTitle, principals->characters);                    
                }

                if (strcmp(name->nconst, princeNode->right->data) > 0) {
                    princeNode = princeNode->left;
                } else {
                    princeNode = princeNode->right;
                }

            }  */          

        } else if (strcmp(command, "title") == 0) {

            title = find_primary_title(tdata, key);
            principals = find_tconst_principals(pdata, title->tconst);
            name = find_nconst_name(ndata, principals->nconst);

            printf("%s : %s\n", name->primaryName, principals->characters);            
        }

    }
    /*freeing all the trees*/
    free_node(ndata->root1);
    free_node(ndata->root2);
    free_node(pdata->root1);
    free_node(pdata->root2);
    free_node(tdata->root1);
    free_node(tdata->root2);
    
    return 0;
}