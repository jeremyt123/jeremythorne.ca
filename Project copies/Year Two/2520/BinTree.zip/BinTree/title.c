/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
*/
#include "title.h"
#include "common.h"
#include "binary.h"

struct title_data *get_title(char *path){
    char *line;
    char *col;
    char *tconst;
    int count;
    char exten[50] = "/title.basics.tsv";
    char *filePath;
    struct title_basics *structAr;
    struct title_data *data;

    FILE *fp;
    /*sets up file path for file*/
    filePath = malloc((sizeof(char) * strlen(path)) + (sizeof(char) * strlen(exten) ));
    strcpy(filePath, path);
    strcat(filePath, exten);
    fp = fopen(filePath, "r");
    free(filePath);
    count = 0;

    line = malloc(sizeof(char*) * 1000);
    while(!feof(fp)){

        fgets(line, 1000, fp);
        col = get_col(line, 2);
        /*counts all lines that are movies and not porn*/
        if(strstr(col, "movie")){
            col = get_col(line, 5);
            if(strstr(col, "0")){
                count++;
            }
        }
    }
    /*mallocs and creates array of title_basics and stores info in title_data*/
    data = malloc(sizeof(struct title_data));
    data->length = count;
    structAr = malloc(sizeof(struct title_basics) * (count + 1));
    count = 0;
    fseek(fp, 0, SEEK_SET);

    while(!feof(fp)){
        fgets(line, 1000, fp);
        col = get_col(line, 2);
        /*adds all non porn movies too the struct array*/
        if(strstr(col, "movie")){
            col = get_col(line,5);
            if(strstr(col, "0")){
                tconst = get_col(line, 1);
                reverse(tconst);
                structAr[count].tconst = tconst;
                structAr[count].primaryTitle = get_col(line, 3);
                count++;
            }
        }
    }
    fclose(fp);
    free(line);

    data->arrAdd = structAr;
    data->root1 = 0;
    data->root2 = 0;

    return data;
}

void build_tindex(struct title_data *data){
    int i;
    for (i = 0; i < data->length; i++){
        add_node(&(data->root1), data->arrAdd[i].primaryTitle, data->arrAdd + i);
    }
}

struct title_basics *find_primary_title(struct title_data *data, char* title){
    struct tree_node *node = NULL;
    struct title_basics *out = NULL;

    node = find_node(data->root1, title);

    if (node == NULL){
        printf("nothing found\n");
        exit(0);
    }

    out = node->data;

    return out;
}

void build_tindex_tconst(struct title_data *data){
    int i;
    for (i = 0; i < data->length; i++){
        add_node(&(data->root2), data->arrAdd[i].tconst, data->arrAdd + i);
    }
}

struct title_basics *find_tconst_title(struct title_data *data, char* tconst){
    struct tree_node *node = NULL;
    struct title_basics *out = NULL;

    node = find_node(data->root2, tconst);

    if (node == NULL){
        printf("nothing found\n");
        exit(0);
    }

    out = node->data;

    return out;
}