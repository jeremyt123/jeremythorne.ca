/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
*/
struct name_basics{
    char *nconst;
    char *primaryName;
};

struct name_data *get_name(char*);
void build_nindex(struct name_data *data);
struct name_basics *find_primary_name(struct name_data *data, char* name);
void build_nindex_nconst(struct name_data *data);
struct name_basics *find_nconst_name(struct name_data *data, char* nconst);
