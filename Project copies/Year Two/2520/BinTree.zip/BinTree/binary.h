/**
 * Jeremy Thorne
 * thornej@uoguelph.ca
*/
void add_node(struct tree_node **root, char* title, void *element);
struct tree_node *find_node(struct tree_node *root, char*);
void free_node(struct tree_node *root);