/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
*/
struct title_basics{
    char *tconst;
    char *primaryTitle;
};

struct title_data *get_title(char *);
void build_tindex(struct title_data *data);
struct title_basics *find_primary_title(struct title_data *data, char* title);
void build_tindex_tconst(struct title_data *data);
struct title_basics *find_tconst_title(struct title_data *data, char* tconst);