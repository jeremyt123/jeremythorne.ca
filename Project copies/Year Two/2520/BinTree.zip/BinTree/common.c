/**
 * Jeremy Thorne
 * thornej@uoguelph.ca
*/
#include "common.h"

char* get_col(char* line, int colNum) {
    int i;
    int firstTab = 0;
    int secTab = 0;
    int tab = 0;
    char* column;

    /*loops through line and keeps track of indices with the tabs*/
    for (i = 0; i < strlen(line); i++) {
        if(line[i] == '\t' || line[i] == '\n'){ /*newline for case of calling last column*/
            tab++;
            if (tab == colNum - 1){
                firstTab = i;
            }
            if (tab == colNum){
                secTab = i;
                break;
            }
        }
    }
    /*length of word = secTab-firstTab*/
    column = malloc(sizeof(char*) * (secTab - firstTab + 1));
    *column = '\0';

    /*if statment for case of calling first row*/
    if (colNum == 1) {
        strncpy(column, line, (secTab - firstTab));
        column[secTab - firstTab] = '\0';
    } else {
        strncpy(column, &line[firstTab + 1], (secTab - firstTab - 1));
        column[secTab - firstTab] = '\0';
    }

    return column;
}

void reverse(char* input) {
    int length, i;
    char *start, *end, temp;

    length = strlen(input);

    start = input;
    /*sets end to end of string*/
    end = input + length - 1;

    for (i = 0; i < (length / 2); i++) {
        /*swaps chars using temp var*/
        temp = *end;
        *end = *start;
        *start = temp;

        start += sizeof(char);
        end -= sizeof(char);
    }
}