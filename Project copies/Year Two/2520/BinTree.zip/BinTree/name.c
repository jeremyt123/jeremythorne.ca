/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
*/
#include "name.h"
#include "common.h"
#include "binary.h"

struct name_data *get_name(char* path){
    char*line;
    char *col;
    char *nconst;
    int count = 0;
    char exten[50] = "/name.basics.tsv";
    char *filePath;
    struct name_basics *structAr;
    struct name_data *data;

    FILE* fp;
    filePath = malloc((sizeof(char) * strlen(path)) + (sizeof(char) * strlen(exten) ));
    strcpy(filePath, path);
    strcat(filePath, exten);
    fp = fopen(filePath, "r");
    free(filePath);
    
    line = malloc(sizeof(char*) * 256);
    while(!feof(fp)){
        
        fgets(line, 256, fp);
        col = get_col(line, 5);
        /*counts all rows with actors or actresses*/
        if (strstr(col, "actor") || strstr(col, "actress")){
            count++;
        }
    }
    /*creates data struct and allocs enough room for name basics struct array*/
    data = malloc(sizeof(struct name_data));
    data->length = count;
    structAr = malloc(sizeof(struct name_basics) * (count+1));
    fseek(fp, 0, SEEK_SET);
    count = 0;

    while(!feof(fp)){
        fgets(line, 256, fp);
        col = get_col(line, 5);
        /*adds all rows with actor or actress to struct array*/
        if (strstr(col, "actor") || strstr(col, "actress")){
            nconst = get_col(line,1);
            reverse(nconst);
            structAr[count].nconst = nconst;
            structAr[count].primaryName = get_col(line, 2);
            count++;
        }
    }
    fclose(fp);
    free(line);

    data->arrAdd = structAr;
    data->root1 = 0;
    data->root2 = 0;
    return data;
}

void build_nindex(struct name_data *data){
    int i;
    for (i = 0; i < data->length; i++){
        add_node(&(data->root1), data->arrAdd[i].primaryName, data->arrAdd + i);
    }
}

struct name_basics *find_primary_name(struct name_data *data, char* name){
    struct tree_node *node = NULL;
    struct name_basics *out = NULL;

    node = find_node(data->root1, name);

    if (node == NULL){
        printf("nothing found\n");
        exit(0);
    }

    out = node->data;

    return out;
}

void build_nindex_nconst(struct name_data *data){
    int i;
    for (i = 0; i < data->length; i++){
        add_node(&(data->root2), data->arrAdd[i].nconst, data->arrAdd + i);
    }
}

struct name_basics *find_nconst_name(struct name_data *data, char* nconst){
    struct tree_node *node = NULL;
    struct name_basics *out = NULL;

    node = find_node(data->root2, nconst);

    if (node == NULL){
        printf("nothing found\n");
        exit(0);
    }

    out = node->data;

    return out;
}