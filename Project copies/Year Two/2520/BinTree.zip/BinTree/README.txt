This program takes 3 TSV files and creates 6 binary trees with their data
The program then allows you to search for a movie title or actor name and will print the corresponding data 