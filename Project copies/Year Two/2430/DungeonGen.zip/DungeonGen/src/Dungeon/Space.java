/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
 */
package Dungeon;

public abstract class Space {

    /**
     * gets description.
     * @return description string
     */
    public abstract String getDescription();

    /**
     * used for adding door to doorlists.
     * @param theDoor door to be added
     */
    public abstract void setDoor(Door theDoor);

}
