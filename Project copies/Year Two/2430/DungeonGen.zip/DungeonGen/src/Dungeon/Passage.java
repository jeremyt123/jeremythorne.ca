/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
 */
package Dungeon;

import dnd.models.Monster;
import dnd.models.Treasure;

import java.io.Serializable;
import java.util.ArrayList;
/*
A passage begins at a door and ends at a door.  It may have many other doors along
the way

You will need to keep track of which door is the "beginning" of the passage
so that you know how to
*/

public class Passage extends Space implements Serializable {

    /**
     * array list which holds all passage sections in the passage.
     */
    private ArrayList<PassageSection> thePassage;

    /**
     * arraylist that holds all doors in the passage.
     */
    private ArrayList<Door> doors;
    /**
     * int for storing current section of in passage.
     */
    private int curSection;

    /**
     * Passage constructor.
     * initializes arraylists and current section int
     */
    public Passage() {
        thePassage = new ArrayList<>();
        doors = new ArrayList<>();
        curSection = 0;
    }

    /**
     * gets arraylist of all doors in passage.
     * @return arraylist of all doors
     */
    public ArrayList<Door> getDoors() {
        return doors;
    }

    /**
     * gets door at certian passage section.
     * @param i section to check for door
     * @return door that is found at section if found, if not found returns null
     */
    public Door getDoor(int i) {
        return thePassage.get(i).getDoor();
    }

    /**
     * Adds monster to section of passage.
     * @param theMonster monster to be added
     * @param i section to be added too
     */
    public void addMonster(Monster theMonster, int i) {
            thePassage.get(i).addMonster(theMonster);
    }

    public void addTreasure(Treasure theTreasure, int i) {
        thePassage.get(i).addTreasure(theTreasure);
    }

    /**
     * gets monster at certain section in passage.
     * @param i section to look in
     * @return if monster is found returns monster if not null
     */
    public Monster getMonster(int i) {
        return thePassage.get(i).getMonster();
    }

    public Treasure getTreasure(int i) {
        return thePassage.get(i).getTreasure();
    }

    /**
     * adds a section to the passage.
     * @param toAdd section to be added
     */
    public void addPassageSection(PassageSection toAdd) {
        if (toAdd != null) {
            thePassage.add(toAdd);
            curSection++;
        }
    }

    /**
     * adds door to the current section of the passage.
     * @param newDoor door to be added
     */
    @Override
    public void setDoor(Door newDoor) {
        if (newDoor != null) {
            thePassage.get(curSection).addDoor(newDoor);
            addDoor(newDoor);
        }
    }

    /**
     * creates the description of the passage by going through each passage section.
     * @return string description of the passage
     */
    @Override
    public String getDescription() {
        StringBuilder desc = new StringBuilder();
        PassageSection sec;
        for (int i = 0; i < thePassage.size(); i++) {
            sec = thePassage.get(i);

            desc.append(sec.getDescription() + "\n");

            if (sec.getMonster() != null) {
                desc.append(monDesc(sec.getMonster()));
            }
            if (sec.getDoor() != null) {
                desc.append(sec.getDoor().getDescription());
            }
            if (sec.getChamber() != null) {
                desc.append(sec.getChamber().getDescription());
            }
            if (sec.getTreasure() != null) {
                desc.append(sec.getTreasure().getWholeDescription());
            }
        }
        return desc.toString();
    }

    /**
     * adds door to doors list.
     * @param theDoor door to add
     */
    public void addDoor(Door theDoor) {
        if (theDoor != null) {
            doors.add(theDoor);
        }
    }

    /**
     * method for getting description of a monster.
     * @param theMonster monster
     * @return description of monster
     */
    private String monDesc(Monster theMonster) {
        StringBuilder mon = new StringBuilder();
        mon.append("Monster: " + theMonster.getDescription() + "; Amount: " + theMonster.getMinNum() + "-" + theMonster.getMaxNum() + "\n");
        return mon.toString();
    }

    /**
     * gets the arraylist of passagesections.
     * @return the arraylist of passagesections
     */
    public ArrayList<PassageSection> getSecList() {
        return thePassage;
    }
}
