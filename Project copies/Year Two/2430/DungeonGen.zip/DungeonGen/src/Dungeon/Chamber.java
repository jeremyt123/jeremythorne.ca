/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
 */
package Dungeon;
import dnd.models.ChamberContents;
import dnd.models.ChamberShape;
import dnd.models.Monster;
import dnd.models.Treasure;

import java.io.Serializable;
import java.util.ArrayList;
import dnd.exceptions.UnusualShapeException;
import dnd.models.Exit;
import dnd.die.D20;

public class Chamber extends Space implements Serializable {

    /**
     * chambercontents object to store chambers contents.
     */
    private ChamberContents myContents;
    /**
     * chambershape object to store chambers shape.
     */
    private ChamberShape myShape;
    /**
     * stores a string of chamber contents description.
     */
    private String contents;
    /**
     * arraylist of all monsters in the chamber.
     */
    private ArrayList<Monster> monsterList;
    /**
     * single monster object for creating new monsters.
     */
    private Monster monGen;
    /**
     * arraylist of all treasure in the chamber.
     */
    private ArrayList<Treasure> treasureList;
    /**
     * single treasure object for creating new treasure.
     */
    private Treasure treasureGen;
    /**
     * arraylist holding all doors in chamber.
     */
    private ArrayList<Door> doorList;
    /**
     * arraylist of all exits in chamber.
     */
    private ArrayList<Exit> exitList;

    /**
     * int of how many exits in the chamber.
     */
    private int numExits;

    /**
     * no param construtor for setting contents, shape, monster, treasure ect.
     */
    public Chamber() {
        D20 dice = new D20();

        myContents = new ChamberContents();
        myContents.chooseContents(dice.roll());

        myShape = ChamberShape.selectChamberShape(dice.roll());

        contents = myContents.getDescription();

        monsterList = new ArrayList<>();
        monGen = new Monster();
        monGen.setType(dice.roll());

        treasureList = new ArrayList<>();
        treasureGen = new Treasure();
        treasureGen.chooseTreasure(dice.roll());
        treasureGen.setContainer(dice.roll());

        doorList = new ArrayList<>();
        exitList = new ArrayList<>();

        numExits = myShape.getNumExits();

        doorSet();
        exitSet();
        contentSet();
    }

    /**
     * double param constructor for using specific chamber contents and shape.
     * @param theShape shape to be used
     * @param theContents contents to be used
     */
    public Chamber(ChamberShape theShape, ChamberContents theContents) {
        D20 dice = new D20();
        myContents = theContents;
        myShape = theShape;

        contents = myContents.getDescription();

        monsterList = new ArrayList<>();
        monGen = new Monster();
        monGen.setType(dice.roll());

        treasureList = new ArrayList<>();
        treasureGen = new Treasure();
        treasureGen.chooseTreasure(dice.roll());
        treasureGen.setContainer(dice.roll());

        doorList = new ArrayList<>();
        exitList = new ArrayList<>();

        numExits = myShape.getNumExits();

        exitSet();
        doorSet();
        contentSet();
    }

    /**
     * sets shape to passed param.
     * @param theShape shape to be set too
     */
    public void setShape(ChamberShape theShape) {
        if (theShape != null) {
            myShape = theShape;
        }
    }

    /**
     * gets arraylist of all doors in chamber.
     * @return arraylist of all doors
     */
    public ArrayList<Door> getDoors() {
        return doorList;
    }

    /**
     * adds monster to chamber.
     * @param theMonster monster to be added
     */
    public void addMonster(Monster theMonster) {
        monsterList.add(theMonster);
    }

    /**
     * gets list of all monsters in chamber.
     * @return arraylist of all monsters in the chamber
     */
    public ArrayList<Monster> getMonsters() {
        return monsterList;
    }

    /**
     * adds treasure to the treasure arraylist.
     * @param theTreasure treasure to be added
     */
    public void addTreasure(Treasure theTreasure) {
        treasureList.add(theTreasure);
    }

    /**
     * gets arraylist of all treasures in chamber.
     * @return arraylist of all treasures
     */
    public ArrayList<Treasure> getTreasureList() {
        return treasureList;
    }

    /**
     * generates description of chamber.
     * @return string with description
     */
    @Override
    public String getDescription() {
        StringBuilder str = new StringBuilder();
        str.append(shapeDesc());
        str.append("-------------------------------------------\n");
        str.append(contentDesc());
        str.append("-------------------------------------------\n");
        str.append(exitDesc());
        return str.toString();
    }

    /**
     * adds door to doorlist.
     * @param newDoor door to be added
     */
    @Override
    public void setDoor(Door newDoor) {
        if (newDoor != null) {
            doorList.add(newDoor);
        }
    }

    /**
     * adds a door to doorlist for every exit in the chamber.
     */
    private void doorSet() {
        for (int i = 0; i < numExits; i++) {
            Door doorNew = new Door();
            doorList.add(doorNew);
        }
    }

    /**
     * adds objects too the room based on what was generated in room contents.
     */
    private void contentSet() {
        if (contents.equals("monster only")) {
            addMonster(monGen);
        } else if (contents.equals("monster and treasure")) {
            addMonster(monGen);
            addTreasure(treasureGen);
        } else if (contents.equals("treasure")) {
            addTreasure(treasureGen);
        }
    }

    /**
     * creates a new exit and stores in exitList for each exit in the room.
     */
    private void exitSet() {
        for (int i = 0; i < numExits; i++) {
            Exit exit = new Exit();
            exitList.add(exit);
        }
    }

    /**
     * generates description for all exits.
     * @return string with description for all exits
     */
    private String exitDesc() {
        StringBuilder exitOut = new StringBuilder();

        exitOut.append("The chamber has " + numExits + " exit(s)\n");
        for (int i = 0; i < numExits; i++) {
            exitOut.append("Door " + (i + 1) + " is on the " + exitList.get(i).getLocation() + "\n");
            //exitOut.append(doorList.get(i).getDescription() + "\n");
        }
        return exitOut.toString();
    }

    /**
     * generates description for content based on what is in room.
     * @return string with room content description
     */
    private String contentDesc() {
        StringBuilder contentDesc = new StringBuilder();

        if (monsterList.size() != 0 && treasureList.size() != 0) {
            contentDesc.append(monDesc());
            contentDesc.append(treasureDesc());
        } else if (monsterList.size() != 0) {
            contentDesc.append(monDesc());
        } else if (treasureList.size() != 0) {
            contentDesc.append(treasureDesc());
        } else {
            contentDesc.append("The chamber is empty\n");
        }
        return contentDesc.toString();
    }

    /**
     * generates description for monster.
     * @return string with monster description
     */
    private String monDesc() {
        StringBuilder mon = new StringBuilder();
        mon.append("The room contains " + monsterList.size() + " type(s) of monster(s)\n");
        for (int i = 0; i < monsterList.size(); i++) {
            mon.append("Monster type " + (i + 1) + ": " + monsterList.get(i).getDescription() + "; Amount: " + monsterList.get(i).getMinNum() + "-" + monsterList.get(i).getMaxNum() + "\n");
        }
        return mon.toString();
    }

    /**
     * generates description for treasure.
     * @return string with treasure description
     */
    private String treasureDesc() {
        StringBuilder treas = new StringBuilder();
        treas.append("The room contains " + treasureList.size() + " treasure(s)\n");
        for (int i = 0; i < treasureList.size(); i++) {
            treas.append(treasureList.get(i).getWholeDescription() + "\n");
        }
        return treas.toString();
    }

    /**
     * generates the description for chamber shape.
     * @return string containing shape description
     */
    private String shapeDesc() {
        StringBuilder sizeDesc = new StringBuilder();

        int length = 0;
        int width = 0;

        try {
            length = myShape.getLength();
            width = myShape.getWidth();
        } catch (UnusualShapeException e) {
        }
        sizeDesc.append("The Chamber has a " + myShape.getShape() + " Shape \n");

        if (length != 0 && width != 0) {
            sizeDesc.append("The rooms area is " + myShape.getArea() + " (" + length + "x" + width + ")\n");
        }

        return sizeDesc.toString();
    }

    /**
     * gets number of exits in the chamber.
     * @return returns int of number of exits
     */
    public int getExitsNum() {
        return numExits;
    }
}
