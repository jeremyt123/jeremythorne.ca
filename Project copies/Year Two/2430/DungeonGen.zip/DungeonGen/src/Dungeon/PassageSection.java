/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
 */
package Dungeon;

import dnd.models.Monster;
import dnd.die.D20;
import dnd.models.Treasure;

import java.io.Serializable;

/* Represents a 10 ft section of passageway */

public class PassageSection implements Serializable {

    /**
     * door door for storing section door.
     */
    private Door door;
    /**
     * monster object for storing section monster.
     */
    private Monster monster;
    /**
     * treasure object for storing section treasure.
     */
    private Treasure treasure;
    /**
     * chamber object for storing section chamber.
     */
    private Chamber chamber;
    /**
     * d20 object for random section generation.
     */
    private D20 dice;
    /**
     * stringbuilder for holding description of section.
     */
    private StringBuilder passDesc;

    /**
     * Constructor for passageSection.
     * sets up d20 and description stringbuilder
     */
    public PassageSection() {
        dice = new D20();
        passDesc = new StringBuilder();

        door = null;
        monster = null;
        chamber = null;
        treasure = null;

        contentSet(sectionGen(dice.roll()));
    }

    /**
     * sets up needed objects for passage section.
     * adds description to stringBuilder
     * @param description description of passage section
     */
    public PassageSection(String description) {
        passDesc = new StringBuilder();
        door = null;
        monster = null;
        chamber = null;
        treasure = null;

        contentSet(description);
    }

    /**
     * returns door in passage section.
     * @return the door
     */
    public Door getDoor() {
        return door;
    }

    /**
     * returns monster in section.
     * @return the monster
     */
    public Monster getMonster() {
        return monster;
    }

    /**
     * returns chamber connected to passage.
     * @return the chamber
     */
    public Chamber getChamber() {
        return chamber;
    }

    public Treasure getTreasure() {
        return treasure;
    }
    /**
     * returns description of passage section.
     * if there is no description set it generates one
     * @return description
     */
    public String getDescription() {
        if (passDesc.length() == 0) {
            passDesc.append(sectionGen(dice.roll()));
        }
        return passDesc.toString();
    }

    /**
     * method which returns passage section based on roll.
     * @param roll roll to be used
     * @return string of what is in passage
     */
    private String sectionGen(int roll) {
        if (roll == 1 || roll == 2) {
            return "passage goes straight for 10 ft";
        } else if (roll == 3 || roll == 4 || roll == 5) {
            return "passage ends in Door to a Chamber";
        } else if (roll == 6 || roll == 7) {
            return "archway (door) to right (main passage continues straight for 10 ft)";
        } else if (roll == 8 || roll == 9) {
            return "archway (door) to left (main passage continues straight for 10 ft)";
        } else if (roll == 10 || roll == 11) {
            return "passage turns to left and continues for 10 ft";
        } else if (roll == 12 || roll == 13) {
            return "passage turns to right and continues for 10 ft";
        } else if (roll == 14 || roll == 15 || roll == 16) {
            return "passage ends in archway (door) to chamber";
        } else if (roll == 17) {
            return "Stairs, (passage continues straight for 10 ft)";
        } else if (roll == 18 || roll == 19) {
            return "Dead End";
        } else if (roll == 20) {
            return "Wandering Monster (passage continues straight for 10 ft)";
        } else {
            return "error";
        }
    }

    /**
     * function cretes the content needed for each passage section that has stuff.
     * @param description description of the passage section
     */
    private void contentSet(String description) {
        if (description.equals("passage ends in Door to a Chamber")) {
            door = new Door();
            chamber = new Chamber();
        } else if (description.equals("archway (door) to right (main passage continues straight for 10 ft)") || description.equals("archway (door) to left (main passage continues straight for 10 ft)")) {
            door = new Door();
            door.setArchway(true);
        } else if (description.equals("passage ends in archway (door) to chamber")) {
            door = new Door();
            door.setArchway(true);
            chamber = new Chamber();
        } else if (description.equals("Wandering Monster (passage continues straight for 10 ft)")) {
            monster = new Monster();
        }
        passDesc.append(description);
    }

    /**
     * sets monster to theMonster.
     * @param theMonster monster to be set
     */
    public void addMonster(Monster theMonster) {
        monster = theMonster;
    }

    public void addTreasure(Treasure theTreasure) {
        treasure = theTreasure;
    }

    /***
     *  sets door to theDoor.
     * @param theDoor door that will be used to set
     */
    public void addDoor(Door theDoor) {
        door = theDoor;
    }

}
