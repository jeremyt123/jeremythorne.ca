/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
 */
package Dungeon;
import java.util.ArrayList;
import java.util.HashMap;
import dnd.models.ChamberShape;
import dnd.models.ChamberContents;
import dnd.die.D20;


public class Level {

    ArrayList<Chamber> chambers;
    ArrayList<Passage> passages;

    public Level() {
        chambers = new ArrayList<>();
        passages = new ArrayList<>();
    }
    /**
     * main method for generating 5 connected chamber level.
     * @param args args
     */
    public void main() {
        D20 dice = new D20();

        Level levelGen = new Level();

        Chamber[] chamberArray = new Chamber[5];
        Chamber temp;

        int doorIndex = 1;
        int totalDoor = 0;

        boolean done = false;

        HashMap<Door, ArrayList<Chamber>> doorMap = new HashMap<>();

        //generates 5 chambers and stores them in an array
        for (int i = 0; i < 5; i++) {
            Chamber cham = new Chamber();
            //used to stop chambers with 5 exits from being used (no unsualshape chambers)
            if (cham.getExitsNum() == 5) {
                ChamberShape shape = ChamberShape.selectChamberShape(1);
                ChamberContents contents = new ChamberContents();
                contents.chooseContents(dice.roll());

                cham = new Chamber(shape, contents);
            }
            chamberArray[i] = cham;
        }

        //bubble sorts the chamber array based on # of exits (high-low)
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (chamberArray[i].getExitsNum() > chamberArray[j].getExitsNum()) {
                    temp = chamberArray[i];
                    chamberArray[i] = chamberArray[j];
                    chamberArray[j] = temp;
                }
            }
        }

        //adds sorted chambers to array list
        for (int i = 0; i < 5; i++) {
            chambers.add(chamberArray[i]);
            totalDoor += chamberArray[i].getExitsNum();
        }

        //putting a blank arraylist in the hashmap for each door in the level
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < chambers.get(i).getExitsNum(); j++) {
                ArrayList<Chamber> tempList = new ArrayList<>();
                doorMap.put(chambers.get(i).getDoors().get(j), tempList);
            }
        }

        //algorithm for connecting doors to chambers in the hashmap
        while (!done) {
            try {
                for (int i = 0; i < 5; i++) {
                    for (int j = 0; j < chambers.get(i).getExitsNum(); j++) {
                        if (doorMap.get(chambers.get(i).getDoors().get(j)).isEmpty()) {
                            doorMap.get(chambers.get(i).getDoors().get(j)).add(chambers.get(j + 1));
                            doorMap.get(chambers.get(j + 1).getDoors().get(i)).add(chambers.get(i));
                        }
                    }
                }
                done = true;
            } catch (Exception e) {
                done = false;
            }
        }

        //creating 2 section passages for all doors (made them simple like it said in the outline)
        for (int i = 0; i < totalDoor; i++) {
            Passage pass = new Passage();
            PassageSection section1 = new PassageSection("passage goes straight for 10 ft");
            PassageSection section2 = new PassageSection("passage goes straight for 10 ft");
            pass.addPassageSection(section1);
            pass.addPassageSection(section2);
            Door door1 = new Door();
            Door door2 = new Door();
            pass.addDoor(door1);
            pass.addDoor(door2);
            passages.add(pass);
        }

        //prints out all chambers and where their exits are conected and the contents of the passages
        /*for (int i = 0; i < 5; i++) {
            System.out.println("\nChamber " + (i + 1));
            System.out.println(chambers.get(i).getDescription());
            for (int j = 0; j < chambers.get(i).getExitsNum(); j++) {
                System.out.println("Chamber " + (i + 1) + " Exit " + j + " is connected to Chamber " + levelGen.getChamberNum(chambers, doorMap.get(chambers.get(i).getDoors().get(j))));
                System.out.println("The passage between the two exits:");
                System.out.println(passages.get(doorIndex - 1).getDescription());
                doorIndex++;
            }
        }*/

    }

    //used to turn chamber object into chamber number to show connections
    private int getChamberNum(ArrayList<Chamber> chambers, ArrayList<Chamber> theChamber) {
        for (int i = 0; i < chambers.size(); i++) {
            if (theChamber.get(0) == chambers.get(i)) {
                return (i + 1);
            }
        }
        return -1;
    }

    public ArrayList<Chamber> getChambers() {
        return chambers;
    }

    public ArrayList<Passage> getPassages() {
        return passages;
    }
}
