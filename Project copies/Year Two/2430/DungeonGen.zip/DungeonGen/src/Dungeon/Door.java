/**
 * Jeremy Thorne
 * 1052007
 * thornej@uoguelph.ca
 */
package Dungeon;
import dnd.models.Exit;
import dnd.models.Trap;

import java.io.Serializable;
import java.util.ArrayList;
import dnd.die.D6;
import dnd.die.D10;
import dnd.die.D20;
import dnd.die.D4;

public class Door implements Serializable {
    /**
     * hold exit object for Door.
     */
    private Exit myExit;
    /**
     * holds trap object for doors with traps.
     */
    private Trap myTrap;

    /**
     * bool for knowing if door is trapped or not.
     */
    private boolean trapped;
    /**
     * bool for if door is open or closed.
     */
    private boolean openStatus;
    /**
     * bool for if door is archway or not.
     */
    private boolean isArch;
    /**
     * bool for is the door is locked or not.
     */
    private boolean lock;

    /**
     * arraylist to hold all spaces.
     */
    private ArrayList<Space> mySpaces;

    /**
     * no parameter constructor.
     * sets all bools to false then rolls based on odds given in roll functions
     */
    public Door() {
        //needs to set defaults
        myExit = new Exit();
        myTrap = new Trap();

        mySpaces = new ArrayList<>();

        trapped = false;
        openStatus = false;
        isArch = false;
        lock = false;

        rollLocked();
        rollOpen();
        rollTrap();
        rollArch();
    }

    /**
     * single param constructor for setting your own exit.
     * @param theExit exit to be setup as
     */
    public Door(Exit theExit) {
        //sets up the door based on the Exit from the tables
        myExit = theExit;
        myTrap = new Trap();

        trapped = false;
        openStatus = false;
        isArch = false;
        lock = false;

        rollLocked();
        rollOpen();
        rollTrap();
        rollArch();
    }

    /**
     * sets door trapped status to flag.
     * if roll is passed uses that for trap description
     * @param flag bool for trapped status
     * @param roll roll for trap description
     */
    public void setTrapped(boolean flag, int...roll) {
        D20 die = new D20();
        trapped = flag;
        if (trapped && roll.length > 0) {
            myTrap.chooseTrap(roll[0]);
        } else if (trapped) {
            myTrap.chooseTrap(die.roll());
        }
    }
    /**
     * sets door status to flag.
     * true == open
     * @param flag bool for open or closed
     */
    public void setOpen(boolean flag) {
        openStatus = flag;
        if (flag) {
            setLocked(false);
        } else {
            setArchway(false);
        }
    }

    /**
     * sets door locked status to flag.
     * @param flag bool for locked or unlocked
     */
    public void setLocked(boolean flag) {
        lock = flag;
        if (flag) {
            setOpen(false);
            setArchway(false);
        }
    }

    /**
     * sets archway to flag.
     * also sets other doorstatus bools accordingly
     * @param flag bool for archway/normal door
     */
    public void setArchway(boolean flag) {
        isArch = flag;
        if (flag) {
            setLocked(false);
            setOpen(true);
        }
    }

    /**
     * used to get trapped status.
     * @return true or false depending on if door is trapped
     */
    public boolean isTrapped() {
        return trapped;
    }

    /**
     * used to get door open status.
     * @return true or false depending on if door is open or closed
     */
    public boolean isOpen() {
        if (isArchway()) {
            return true;
        }
        return openStatus;
    }
    /**
     * used to get if door is archway or not.
     * @return true if archway false if normal door
     */
    public boolean isArchway() {
        return isArch;
    }

    /**
     * gets description for the door trap.
     * @return string with trap description
     */
    private String getTrapDescription() {
        return myTrap.getDescription();
    }

    /**
     * returns the 2 spaces connected by door.
     * @return arraylist of 2 spaces
     */
    public ArrayList<Space> getSpaces() {
        return mySpaces;
    }

    /**
     * sets connected spaces and adds them into the spaces arraylist.
     * @param spaceOne first space to add
     * @param spaceTwo second space to add
     */
    public void setSpaces(Space spaceOne, Space spaceTwo) {
        mySpaces.add(spaceOne);
        mySpaces.add(spaceTwo);

        spaceOne.setDoor(this);
        spaceTwo.setDoor(this);
    }

    /**
     * used to get description of the door.
     * @return string description of door
     */
    public String getDescription() {

        StringBuilder doorDesc = new StringBuilder();
        if (isArchway()) {
            doorDesc.append("The exit is an Archway\n");
        } else {
            if (isOpen()) {
                doorDesc.append("The door is Open\n");
            } else {
                doorDesc.append("The door is Closed ");
                if (isLocked()) {
                    doorDesc.append("and Locked\n");
                } else {
                    doorDesc.append("and Unlocked\n");
                }
            }
        }

        if (isTrapped() && isArchway()) {
            doorDesc.append("The archway is Trapped\n");
            doorDesc.append("The archways trap is:\n" + getTrapDescription() + "\n");
        } else if (isTrapped()) {
            doorDesc.append("The door is Trapped\n");
            doorDesc.append("The doors trap is:\n" + getTrapDescription() + "\n");
        }

        return doorDesc.toString();
    }

    /**
     * rolls a 1/10 chance for the door to be an archway.
     */
    private void rollArch() {
        D10 dice = new D10();
        if (dice.roll() == 1) {
            setArchway(true);
            setOpen(true);
            setLocked(false);
        }
    }

    /**
     * rolls a 1/20 chance for the door to be locked.
     */
    private void rollTrap() {
        D20 dice = new D20();
        if (dice.roll() == 1) {
            setTrapped(true);
        }
    }

    /**
     * rolls a 1/2 chance for the door to be open or closed.
     */
    private void rollOpen() {
        D4 dice = new D4();
        if (dice.roll() == 1 || dice.roll() == 2) {
            setOpen(true);
            setLocked(false);
        }
    }

    /**
     * used to get locked status of door.
     * @return true == locked false == unlocked
     */
    public boolean isLocked() {
        if (isArchway()) {
            return false;
        }
        return lock;
    }

    /**
     * rolls 1/6 for locked status of door.
     */
    private void rollLocked() {
        D6 dice = new D6();
        if (dice.roll() == 1) {
            setLocked(true);
        }
    }

}
