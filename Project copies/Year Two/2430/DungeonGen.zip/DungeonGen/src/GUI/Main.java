package GUI;

import Dungeon.Chamber;
import Dungeon.Door;
import Dungeon.Passage;
import dnd.die.D20;
import dnd.models.Monster;
import dnd.models.Treasure;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.*;

import java.io.*;
import java.util.ArrayList;

public class Main extends Application implements EventHandler<ActionEvent> {

    //instance variables
    private Button editButton;
    private Controller controller;
    private ArrayList<Passage> passages;
    private ArrayList<Chamber> chambers;
    private BorderPane layout;
    private Stage stage;
    private ListView listView;
    private ArrayList<String> monsters;
    private ArrayList<Integer> monsterRolls;
    private ArrayList<String> treasures;
    private ArrayList<Integer> treasureRolls;
    private ListView editLV;
    private String stylePath = "res/stylesheet.css";
    private Stage removerPopStage;

    //sets up first screen shown and instance objects
    @Override
    public void start(Stage primaryStage) throws Exception {
        controller = new Controller(this);

        monsters = new ArrayList<>();
        monsterRolls = new ArrayList<>();
        treasures = new ArrayList<>();
        treasureRolls = new ArrayList<>();
        monListFill();
        treasListFill();

        primaryStage.setTitle("Vaporwave Dungeon Generator");

        editButton = new Button("Edit Selected Space");
        editButton.setOnAction(this);

        MenuBar bar = menuBarSet();


        layout = new BorderPane();
        layout.setLeft(listViewSet());
        layout.setTop(bar);
        VBox box = new VBox(layout);

        box.getChildren().addAll(editButton);
        box.setPadding(new Insets(10, 10, 10, 10));
        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);

        Scene scene = new Scene(box, 1000, 500);
        scene.getStylesheets().add(stylePath);
        primaryStage.setScene(scene);
        primaryStage.show();

        stage = primaryStage;
    }
    //creates menu bar for saving/loading
    private MenuBar menuBarSet() {
        MenuBar bar = new MenuBar();

        Menu option1 = new Menu("File");

        MenuItem save = new MenuItem("Save");
        MenuItem load = new MenuItem("Load");

        option1.getItems().addAll(save, load);

        bar.getMenus().add(option1);

        EventHandler<ActionEvent> saveEvent = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    serialize(saveFile());
                } catch (IOException e) {
                    System.out.println("Serialization failed");
                }
            }
        };
        save.setOnAction(saveEvent);

        EventHandler<ActionEvent> loadEvent = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    deserialize(chooseFile());
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException i) {
                    i.printStackTrace();
                }
            }
        };
        load.setOnAction(loadEvent);

        return bar;
    }
    //method for choosing location/name to save too
    private String saveFile() {
        FileChooser choose = new FileChooser();
        choose.setTitle("Choose location to save data");
        choose.getExtensionFilters().add(new FileChooser.ExtensionFilter("ser files", "*.ser"));
        File file = choose.showSaveDialog(stage);
        return file.getAbsolutePath();
    }
    //method for choosing file to load
    private String chooseFile() {
        FileChooser choose = new FileChooser();
        choose.setTitle("Choose file to load (.ser)");

        choose.getExtensionFilters().add(new FileChooser.ExtensionFilter("ser files", "*.ser"));

        File file = choose.showOpenDialog(stage);
        return file.getAbsolutePath();
    }
    //method for serializing the chambers and passages
    private void serialize(String path) throws IOException {
        try {
            FileOutputStream fileOut = new FileOutputStream(path);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);

            out.writeObject(chambers);
            out.writeObject(passages);
            out.close();
            fileOut.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }
    //method for deserializing and setting instances vars
    private void deserialize(String path) throws IOException, ClassNotFoundException {
        try {
            FileInputStream fileIn = new FileInputStream(path);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            chambers = (ArrayList<Chamber>) in.readObject();
            passages = (ArrayList<Passage>) in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException i) {
            System.out.println("IO Exception");
            return;
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found");
            return;
        }

    }
    //sets up main listview with all chambers and passages
    private ListView listViewSet(){
        ArrayList<String> contents = new ArrayList<String>();

        chambers = controller.getChambers();
        passages = controller.getPassages();

        for (int i = 0; i < chambers.size(); i++) {
            contents.add("Chamber " + (i + 1));
        }

        for (int i = 0; i < passages.size(); i++) {
            contents.add("Passage " + (i + 1));
        }

        listView = new ListView(FXCollections.observableArrayList(contents));
        listView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                updateView();
            }
        });
        return listView;
    }
    //updates the information in the center of the screen when something is added/removed
    private void updateView() {
        if (listView.getSelectionModel().getSelectedIndex() < 5) {
            TextArea text = new TextArea("Chamber " + (listView.getSelectionModel().getSelectedIndex() + 1) + "\n\n" + chambers.get(listView.getSelectionModel().getSelectedIndex()).getDescription());
            text.setWrapText(true);
            layout.setCenter(text);
            layout.setRight(dropDownSet(chambers.get(listView.getSelectionModel().getSelectedIndex()).getDoors().size(), listView));
        } else {
            TextArea text = new TextArea("Passage " + (listView.getSelectionModel().getSelectedIndex() - 4) + "\n\n" + passages.get(listView.getSelectionModel().getSelectedIndex() - 5).getDescription());
            text.setWrapText(true);
            layout.setCenter(text);
            layout.setRight(dropDownSet(2, listView));
        }
    }
    //method for creating the door drop down
    private ChoiceBox dropDownSet(int size, ListView listView) {
        ChoiceBox<String> dropDown = new ChoiceBox<String>();
        for (int i = 0; i < size; i++) {
            dropDown.getItems().add("Door " + (i + 1));
        }

        dropDown.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                if(listView.getSelectionModel().getSelectedIndex() < 5) {
                    doorPop(chambers.get(listView.getSelectionModel().getSelectedIndex()).getDoors().get(dropDown.getSelectionModel().getSelectedIndex()));
                } else {
                    doorPop(passages.get(listView.getSelectionModel().getSelectedIndex() - 5).getDoors().get(dropDown.getSelectionModel().getSelectedIndex()));
                }

            }
        });

        return dropDown;
    }
    //huge method that handles most of the button functions in the program
    @Override
    public void handle(ActionEvent actionEvent) {
        if (actionEvent.getSource().toString().contains("Edit Selected Space")) {
            if (listView.getSelectionModel().getSelectedIndex() == -1) {
                errorPop("Error: No Space Selected", "Error");
            } else {
                editPop();
            }
            //listView.fireEvent(MouseEvent);
        } else if (actionEvent.getSource().toString().contains("Add Monster")) {
            listPop(true, true);

        } else if (actionEvent.getSource().toString().contains("Add Treasure")) {
            listPop(false, true);

        } else if (actionEvent.getSource().toString().contains("Remove Monster")) {
            if (listView.getSelectionModel().getSelectedIndex() < 5){
                if ( chambers.get(listView.getSelectionModel().getSelectedIndex()).getMonsters().size() == 0) {
                    errorPop("Error: No Monsters in selected Chamber", "Error");
                } else {
                    listPop(true, false);
                }
            } else {
                if (passages.get(listView.getSelectionModel().getSelectedIndex() - 5).getMonster(1) == null) {
                    errorPop("Error: No Monster in selected Passage", "Error");
                } else {
                    confirmPop("Are you sure you want to remove the Monster in selected Passage?", true);
                }
            }

        } else if (actionEvent.getSource().toString().contains("Remove Treasure")) {
            if (listView.getSelectionModel().getSelectedIndex() < 5){
                if (chambers.get(listView.getSelectionModel().getSelectedIndex()).getTreasureList().size() == 0) {
                    errorPop("Error: No Treasures in selected Chamber", "Error");
                } else {
                    listPop(false, false);
                }
            } else {
                if (passages.get(listView.getSelectionModel().getSelectedIndex() - 5).getTreasure(1) == null) {
                    errorPop("Error: No Treasure in selected Passage", "Error");
                } else {
                    confirmPop("Are you sure you want to remove the Treasure in selected Passage?", false);
                }
            }


        } else if (actionEvent.getSource().toString().contains("Confirm add Monster")) {
            if (editLV.getSelectionModel().getSelectedIndex() == -1){
                errorPop("Error: No Monster Selected", "Error");
            } else {
                Monster mon = new Monster();
                mon.setType(monsterRolls.get(editLV.getSelectionModel().getSelectedIndex()));
                if (editLV.getSelectionModel().getSelectedIndex() == -1) {
                    errorPop("Error: No Monster Selected", "Error");
                } else if (listView.getSelectionModel().getSelectedIndex() < 5){
                    chambers.get(listView.getSelectionModel().getSelectedIndex()).getMonsters().add(mon);
                } else {
                    passages.get(listView.getSelectionModel().getSelectedIndex() - 5).addMonster(mon, 1);
                }
                updateView();
                errorPop("Selected Monster has been added", "Monster added");
            }

        } else if (actionEvent.getSource().toString().contains("Confirm add Treasure")) {
            if (editLV.getSelectionModel().getSelectedIndex() == -1) {
                errorPop("Error: No Treasure Selected", "Error");
            } else {
                Treasure tres = new Treasure();
                tres.setContainer(new D20().roll());
                tres.chooseTreasure(treasureRolls.get(editLV.getSelectionModel().getSelectedIndex()));
                if (editLV.getSelectionModel().getSelectedIndex() == -1) {
                    errorPop("Error: No Treasure Selected", "Error");
                } else if (listView.getSelectionModel().getSelectedIndex() < 5){
                    chambers.get(listView.getSelectionModel().getSelectedIndex()).getTreasureList().add(tres);
                } else {
                    passages.get(listView.getSelectionModel().getSelectedIndex() - 5).addTreasure(tres, 1);
                }
                updateView();
                errorPop("Selected Treasure has been added", "Treasure added");
            }

        } else if (actionEvent.getSource().toString().contains("Confirm remove Monster")) {
            if (editLV.getSelectionModel().getSelectedIndex() == -1) {
                errorPop("Error: No Monster Selected", "Error");
            } else if (listView.getSelectionModel().getSelectedIndex() < 5) {
                chambers.get(listView.getSelectionModel().getSelectedIndex()).getMonsters().remove(editLV.getSelectionModel().getSelectedIndex());
            } else {
                passages.get(listView.getSelectionModel().getSelectedIndex() - 5).addTreasure(null, 1);
            }
            removerPopStage.hide();
            if (chambers.get(listView.getSelectionModel().getSelectedIndex()).getMonsters().size() > 0) {
                listPop(true,false);
            }
            updateView();
            errorPop("Selected Monster has been removed", "Remove Monster");
        } else if (actionEvent.getSource().toString().contains("Confirm remove Treasure")) {
            if (editLV.getSelectionModel().getSelectedIndex() == -1) {
                errorPop("Error: No Treasure Selected", "Error");
            } else {
                chambers.get(listView.getSelectionModel().getSelectedIndex()).getTreasureList().remove(editLV.getSelectionModel().getSelectedIndex());
            }
            removerPopStage.hide();
            if (chambers.get(listView.getSelectionModel().getSelectedIndex()).getTreasureList().size() > 0) {
                listPop(false,false);
            }
            updateView();
            errorPop("Selected Treasure has been removed", "Remove Treasure");
        } else if (actionEvent.getSource().toString().contains("Delete Monster in Passage")) {
            passages.get(listView.getSelectionModel().getSelectedIndex() - 5).addMonster(null, 1);
            updateView();
            errorPop("The Monster has been removed", "Remove Monster");

        } else if (actionEvent.getSource().toString().contains("Delete Treasure in Passage")) {
            passages.get(listView.getSelectionModel().getSelectedIndex() - 5).addTreasure(null, 1);
            updateView();
            errorPop("The Treasure has been removed", "Remove Treasure");
        }
    }
    //creates a popup with a listview for adding/removing from chambers/passages
    private void listPop(boolean monster, boolean add) {

        removerPopStage = new Stage();
        removerPopStage.initModality(Modality.APPLICATION_MODAL);
        removerPopStage.setTitle("Add Object to Space");
        removerPopStage.initOwner(stage);

        Button confirm;
        if (monster && add) {
            editLV = new ListView(FXCollections.observableArrayList(monsters));
            confirm = new Button("Confirm add Monster");
            confirm.setOnAction(this);
        }
        else if (!monster && add) {
            editLV = new ListView(FXCollections.observableArrayList(treasures));
            confirm = new Button("Confirm add Treasure");
            confirm.setOnAction(this);
        } else if (monster) {
            ArrayList<String> monDescs = new ArrayList<>();
            for (int i = 0; i < chambers.get(listView.getSelectionModel().getSelectedIndex()).getMonsters().size(); i++ ) {
                monDescs.add(chambers.get(listView.getSelectionModel().getSelectedIndex()).getMonsters().get(i).getDescription());
            }
            editLV = new ListView(FXCollections.observableArrayList(monDescs));
            confirm = new Button("Confirm remove Monster");
            confirm.setOnAction(this);
        } else {
            ArrayList<String> treasDescs = new ArrayList<>();
            for (int i = 0; i < chambers.get(listView.getSelectionModel().getSelectedIndex()).getTreasureList().size(); i++) {
                treasDescs.add(chambers.get(listView.getSelectionModel().getSelectedIndex()).getTreasureList().get(i).getDescription());
            }
            editLV = new ListView(FXCollections.observableArrayList(treasDescs));
            confirm = new Button("Confirm remove Treasure");
            confirm.setOnAction(this);
        }

        VBox vb = new VBox(10);
        vb.getChildren().addAll(editLV, confirm);
        vb.setAlignment(Pos.CENTER);

        Scene popScene = new Scene(vb, 300, 250);
        popScene.getStylesheets().add(stylePath);
        removerPopStage.setScene(popScene);
        removerPopStage.show();
    }
    //creaetes popup with information about the door selected
    private void doorPop(Door theDoor) {
        Stage popStage = new Stage();

        popStage.initModality(Modality.APPLICATION_MODAL);
        popStage.setTitle("Door Info");
        popStage.initOwner(stage);

        TextArea text = new TextArea(theDoor.getDescription());
        text.setWrapText(true);

        VBox popBox = new VBox(20);
        popBox.getChildren().add(text);

        Scene popScene = new Scene(popBox, 500, 150);
        popScene.getStylesheets().add(stylePath);
        popStage.setScene(popScene);
        popStage.show();
    }
    //creates popup for editing the space
    private void editPop() {
        Stage popStage = new Stage();
        //makes it so you gotta deal with the popup
        popStage.initModality(Modality.APPLICATION_MODAL);
        popStage.setTitle("Edit space");
        popStage.initOwner(stage);

        Button addMon = new Button("Add Monster");
        addMon.setOnAction(this);
        Button removeMon = new Button("Remove Monster");
        removeMon.setOnAction(this);
        Button addTreas = new Button("Add Treasure");
        addTreas.setOnAction(this);
        Button removeTreas = new Button("Remove Treasure");
        removeTreas.setOnAction(this);

        VBox popBox = new VBox(20);
        popBox.getChildren().addAll(addMon, removeMon, addTreas, removeTreas);
        popBox.setAlignment(Pos.CENTER);

        Scene popScene = new Scene(popBox, 300, 200);
        popScene.getStylesheets().add(stylePath);
        popStage.setScene(popScene);
        popStage.show();
    }
    //method for easily creating popups with set messages and titles
    private void errorPop(String message, String title) {
        Stage popStage = new Stage();

        popStage.initModality(Modality.APPLICATION_MODAL);
        popStage.setTitle(title);
        popStage.initOwner(stage);

        Text text = new Text(message);

        VBox popBox = new VBox(20);
        popBox.getChildren().add(text);
        popBox.setAlignment(Pos.CENTER);

        Scene popScene = new Scene(popBox, 400, 50);
        popScene.getStylesheets().add(stylePath);
        popStage.setScene(popScene);
        popStage.show();
    }
    //popup to confirm things
    private void confirmPop(String message, boolean monster){
        Stage popStage = new Stage();

        popStage.initModality(Modality.APPLICATION_MODAL);
        popStage.setTitle("Remove object from passage");
        popStage.initOwner(stage);

        Text text = new Text(message);
        Button confirm;
        if (monster){
            confirm = new Button("Delete Monster in Passage");
        } else {
            confirm = new Button("Delete Treasure in Passage");
        }

        confirm.setOnAction(this);

        VBox popBox = new VBox(20);
        popBox.getChildren().addAll(text, confirm);
        popBox.setAlignment(Pos.CENTER);

        Scene popScene = new Scene(popBox, 400, 100);
        popScene.getStylesheets().add(stylePath);
        popStage.setScene(popScene);
        popStage.show();
    }
    //creates list with all monsters and another list with their respective rolls
    private void monListFill() {
        monsters.add("Ant, giant");
        monsterRolls.add(1);
        monsters.add("Badger");
        monsterRolls.add(3);
        monsters.add("Beetle, fire");
        monsterRolls.add(5);
        monsters.add("Demon, manes");
        monsterRolls.add(15);
        monsters.add("Dwarf");
        monsterRolls.add(16);
        monsters.add("Ear Seeker");
        monsterRolls.add(18);
        monsters.add("Elf");
        monsterRolls.add(19);
        monsters.add("Gnome");
        monsterRolls.add(20);
        monsters.add("Goblin");
        monsterRolls.add(22);
        monsters.add("Hafling");
        monsterRolls.add(27);
        monsters.add("Hobgoblin");
        monsterRolls.add(29);
        monsters.add("Human Bandit");
        monsterRolls.add(34);
        monsters.add("Kobold");
        monsterRolls.add(49);
        monsters.add("Orc");
        monsterRolls.add(55);
        monsters.add("Piercer");
        monsterRolls.add(67);
        monsters.add("Rat, giant");
        monsterRolls.add(71);
        monsters.add("Rot grub");
        monsterRolls.add(84);
        monsters.add("Shrieker");
        monsterRolls.add(86);
        monsters.add("Skeleton");
        monsterRolls.add(97);
        monsters.add("Zombie");
        monsterRolls.add(100);
    }
    //creates list with all treasures and andother list with their respective rolls
    private void treasListFill() {
        treasures.add("1000 copper pieces/level");
        treasureRolls.add(1);
        treasures.add("1000 silver pieces/level");
        treasureRolls.add(26);
        treasures.add("750 electrum pieces/level");
        treasureRolls.add(51);
        treasures.add("250 gold pieces/level");
        treasureRolls.add(66);
        treasures.add("100 platinum pieces/level");
        treasureRolls.add(81);
        treasures.add("1-4 gems/level");
        treasureRolls.add(91);
        treasures.add("1 piece jewellery/level");
        treasureRolls.add(96);
        treasures.add("1 magic item (roll on Magic item table)");
        treasureRolls.add(99);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
