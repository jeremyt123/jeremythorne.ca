package GUI;

import Dungeon.Chamber;
import Dungeon.Level;
import Dungeon.Passage;
import dnd.models.Monster;
import dnd.models.Treasure;

import java.util.ArrayList;

public class Controller {
    private Level dunGen;
    private ArrayList<Chamber> chambers;
    private ArrayList<Passage> passages;

    public Controller(Main gui){
        dunGen = new Level();
        dunGen.main();
    }

    public ArrayList<Chamber> getChambers() {
        chambers = dunGen.getChambers();
        return chambers;
    }

    public ArrayList<Passage> getPassages(){
        passages = dunGen.getPassages();
        return passages;
    }
}
