﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomStringGen
{
    class Program
    {
        static string randomStringGen (int length, params char[] remove)
        {
            Random rnd = new Random();
            string output = "";
            char random;
            while(output.Length < length)
            {
                random = (char)rnd.Next(33, 126);

                for (int i = 0; i < remove.Length; i++)
                    if (random == remove[i])
                        random = ' ';
                output += random;
                output = output.Trim();
            }
            return output;
        }
        static void Main(string[] args)
        {
            int length = 8;
            char[] letters = { 'a', 'b', 'c', 'd'};     
            Console.WriteLine(randomStringGen(length, letters));
            Console.ReadLine();

        }
    }
}
