﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Int_sort
{
    class Program
    {
        static void Main(string[] args)
        {
            //very brute force int sorting method
            int[] ints = { 1, 6, 4, 98, 32, 2, 43, 1, 53, 9, 16 }, output = new int[ints.Length];
            int destroy = 0;

            //loops through for each int
            for (int i = 0; i < ints.Length; i++)
            {
                int low = int.MaxValue;
                for (int j = 0; j < ints.Length; j++)
                {
                    //find the lowest number by looping through all the nums
                    if (ints[j] < low)
                    {
                        low = ints[j];
                        destroy = j;
                    }
                    //basically removes the int from the sequence
                    if (j == ints.Length - 1)
                        ints[destroy] = int.MaxValue;
                }
                output[i] = low;
            }
            //outputs each number in output array
            foreach (int value in output)
                Console.Write(value + " ");
            Console.ReadLine();
        }
    }
}
