﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {

            string partsData = File.ReadAllText("partslist.txt");
            string[] partsArray = partsData.Split(',', '\r');
            string ordersData = File.ReadAllText("orders.txt");
            string[] ordersArray = ordersData.Split(',','\r','\n');
            int customers = 0;
            //finding amount of orders to run through
            for (int i = 0; i < ordersArray.Length; i++)
                if (ordersArray[i] == "")
                    customers++;

            int firstName = 0, lastName = 1, index = 0, orders = 3;
            double totalCost = 0, tax = 0;
            //main loop running through every order
            for (int i = 0; i < customers; i++)
            {
                char[] firstNameArray = ordersArray[firstName].ToCharArray();
                StreamWriter writer = new StreamWriter(firstNameArray[0] + ordersArray[lastName] + ".txt");
                writer.WriteLine("IER: {0} {1}", ordersArray[firstName], ordersArray[lastName]);
                writer.WriteLine();
                writer.WriteLine("SKU \t\t PRODUCT NAME \t\t\t\t\tPRICE ");
                writer.WriteLine("-----------------------------------------------------------------------");
                index += 2;
                while (ordersArray[index] != "")
                {
                    writer.Write("{0,-17}",ordersArray[index]);
                    
                    for (int l = 0; l < partsArray.Length; l++)
                    {
                        string ordernum = ordersArray[index];
                        if (ordernum == partsArray[l].Trim())
                        {
                            writer.Write("{0,-47}", partsArray[l + 1]);
                            writer.WriteLine("${0,-15}", partsArray[l + 2]);
                            totalCost += double.Parse(partsArray[l + 2]);
                            orders += 1;
                        }
                    }
                   index += 1;
                }
                writer.WriteLine("-----------------------------------------------------------------------");
                writer.WriteLine("{0,-64}${1,-10}","PRE-TAX", totalCost);
                tax += totalCost * 0.13;
                writer.WriteLine("{0,-64}${1,-10}","TAX", Math.Round(tax, 2));
                totalCost += tax;
                writer.WriteLine("-----------------------------------------------------------------------");
                writer.WriteLine("{0,-64}${1,-10}","TOTAL", Math.Round(totalCost, 2));
                writer.WriteLine();

                //resetting vars for next invoice
                index += 1;
                firstName += orders;
                lastName += orders;
                orders = 3;
                totalCost = 0;
                tax = 0;
                writer.Close();
            }

            Console.WriteLine("Invoices in bin");
            Console.ReadLine();
        }
    }
}
