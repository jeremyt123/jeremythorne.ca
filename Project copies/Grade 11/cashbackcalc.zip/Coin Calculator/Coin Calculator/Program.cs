﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coin_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("input how much money will be paid back");
            double cashAmount = double.Parse(Console.ReadLine());
            int hundered = 0, fifty = 0, twenty = 0, ten = 0, five = 0, toonies = 0 , loonies = 0, quarters = 0, dimes = 0, nickels = 0, pennies = 0;

            while (cashAmount > 0)
            {
                if (cashAmount >= 100)
                {
                    hundered++;
                    cashAmount -= 100;
                }
                else if (cashAmount >= 50)
                {
                    fifty++;
                    cashAmount -= 50;
                }
                else if (cashAmount >= 20)
                {
                    twenty++;
                    cashAmount -= 20;
                }
                else if (cashAmount >= 10)
                {
                    ten++;
                    cashAmount -= 10;
                }
                else if (cashAmount >= 5)
                {
                    five++;
                    cashAmount -= 5;
                }
                else if (cashAmount >= 2)
                {
                    toonies++;
                    cashAmount -= 2;
                }
                else if (cashAmount >= 1)
                {
                    loonies++;
                    cashAmount -= 1;
                }
                else if (cashAmount >= 0.25)
                {
                    quarters++;
                    cashAmount -= 0.25;
                }
                else if (cashAmount >= 0.10)
                {
                    dimes++;
                    cashAmount -= 0.10;
                }
                else if (cashAmount >= 0.05)
                {
                    nickels++;
                    cashAmount -= 0.05;
                }
                else if (cashAmount >= 0.01)
                {
                    pennies++;
                    cashAmount -= 0.01;
                }
            }
            Console.WriteLine("{0} hundereds, {1} fifties, {2} twenties, {3} tens, {4} fives, {5} toonies, {6} loonies, {7} quarters, {8} dimes, {9} nickles, {10} pennies", hundered, fifty, twenty, ten, five, toonies, loonies, quarters, dimes, nickels, pennies);
            Console.ReadLine();
        }
    }
}
