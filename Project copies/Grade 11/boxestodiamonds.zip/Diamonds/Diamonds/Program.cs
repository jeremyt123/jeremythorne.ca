﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diamonds
{
    class Program
    {
        static void Main(string[] args)
        {
            //reads file puts into array
            string boxesData = File.ReadAllText("Boxes.txt");
            string[] boxesDataArray = boxesData.Split('\n');
            for (int i = 0; i < boxesDataArray.Length; i++)
                boxesDataArray[i] = boxesDataArray[i].Trim();
            int index = 0, numofBoxes = 1;
            for (int i = 0; i < boxesDataArray.Length; i++)
                if (boxesDataArray[i] == "")
                    numofBoxes += 1;
            int[] sizes = new int[numofBoxes];
            //finding the # of boxes and the sizes
            for (int i = 0; i < 3; i++)
            {
                sizes[i] = boxesDataArray[index].Length;
                index += boxesDataArray[index].Length + 1;
            }    
            //loops through whole file
            for (int l = 0; l < sizes.Length; l++)
            {
                    //executes the diamond creation
                    int diamondSize = sizes[l];
                    int spaces = diamondSize / 2, stars = 1, loops = diamondSize / 2;
                    //top of diamond
                    for (int i = 0; i < loops; i++) 
                    {
                        for (int t = 0; t < spaces; t++) 
                            Console.Write(" "); 
                        for (int t = 0; t < stars; t++) 
                            Console.Write("*");
                        Console.WriteLine();
                        stars += 2;
                        spaces -= 1;
                    }
                    stars -= 2;
                    spaces += 1;
                    //middle
                    for (int i = 0; i < diamondSize; i++)
                            Console.Write("*");   
                    Console.WriteLine();
                    //bottom
                    for (int i = 0; i < loops; i++)
                    {
                        for (int t = 0; t < spaces; t++)
                            Console.Write(" "); 
                        for (int t = 0; t < stars; t++)
                            Console.Write("*");
                        Console.WriteLine();
                        stars -= 2;
                        spaces += 1;
                    }
                    Console.WriteLine();
                }
            Console.ReadLine();
        }
    }
}
