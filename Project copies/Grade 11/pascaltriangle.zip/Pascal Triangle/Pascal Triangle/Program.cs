﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pascal_Triangle
{
    class Program
    {
        static void Main(string[] args)
        {
            string triString = Console.ReadLine();
            int triSize = int.Parse(triString), lineLength = 2;
            double num;
            string[] prevLine = { "1", "1" };

            string curLine = " ";
            StreamWriter writer = new StreamWriter("output.txt");

            for (int i = 0; i < triSize; i++)
            {
                // UNCOMMENT FOR JUSTIFICATION
                //for (int j = 0; j < triSize - i; j++) 
                //    writer.Write(" ");

                writer.Write("1");

                //for writing the lines after the first 2
                string[] newLine = new string[i + 1];
                if (i > 1)
                {
                    newLine[0] += "1";
                    for (int o = 1; o < lineLength; o++)
                    {
                        num = double.Parse(prevLine[o]) + double.Parse(prevLine[o - 1]);
                        curLine += num;
                        writer.Write(curLine);

                        newLine[o] += curLine;
                        curLine = " ";
                    }
                    newLine[lineLength] += "1";

                    prevLine = newLine;
                    lineLength += 1;
                }

                if (i > 0)
                    writer.Write(" 1");
                writer.WriteLine();

            }
            writer.Close();

            Console.WriteLine("Your Pascal Triangle is in the bin folder");
            Console.ReadLine();
        }
    }

}
