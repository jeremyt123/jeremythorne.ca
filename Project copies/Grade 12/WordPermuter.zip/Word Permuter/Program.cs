﻿// WORD PERMUTER
// By Jeremy Thorne
// This program takes in a input file of words and outputs all the words that different combinations of the letters in the word can make
// Output file is put into the debug folder
using System;
using System.Collections.Generic;
using System.IO;

namespace Word_Permuter
{
    class Program
    {
        //permute method
        static void permute(char[] wordArr, string wordOut, int startDepth, int endDepth, int maxDepth, List<string> dict, List<string> used)
        {
            if (startDepth == maxDepth)
            {
                if (dict.Contains(wordOut) && (!used.Contains(wordOut)))
                {
                    writer.Write(" {0}", wordOut);
                    used.Add(wordOut);
                }
            }
            else
            {
                for (int i = startDepth; i <= endDepth; i++)
                {
                    string wordMix = wordOut + wordArr[i];
                    swap(ref wordArr[startDepth], ref wordArr[i]);

                    permute(wordArr, wordMix, startDepth + 1, endDepth, maxDepth, dict, used);

                    //reswaps to original array
                    swap(ref wordArr[startDepth], ref wordArr[i]);
                }
            }
        }

        //declaring the writer out here so I can use it in the Permute method
        static StreamWriter writer = new StreamWriter("output.txt");

        static void Main(string[] args)
        {
            //puts all the words from the dictionary into a list
            StreamReader dictReader = new StreamReader("dictionary.txt");
            List<string> words = new List<string>();
            while (!dictReader.EndOfStream)
            {
                words.Add(dictReader.ReadLine());
            }

            List<string> usedWords = new List<string>();

            StreamReader reader = new StreamReader("words.txt");

            while (!reader.EndOfStream)
            {
                string word = reader.ReadLine();

                char[] wordArr = word.ToCharArray();

                writer.WriteLine(word);

                writer.WriteLine("-------------------------------------------------------------------------------------------");

                //starts at 2 because you dont want words less than 2 letters 
                for (int i = 2; i <= word.Length; i++)
                {
                    writer.Write("{0} letter words =>", i);
                    permute(wordArr, "", 0, word.Length - 1, i, words, usedWords);
                    writer.WriteLine();
                }
                writer.WriteLine();

                usedWords.Clear();
            }

            writer.Close();
            reader.Close();
        }

        //method for switching two chars
        static void swap(ref char firstChar, ref char secondChar)
        {
            char hold = firstChar;
            firstChar = secondChar;
            secondChar = hold;
        }
    }
}
