﻿╦ ╦╔═╗╦═╗╔╦╗  ╔═╗╔═╗╦═╗╔╦╗╦ ╦╔╦╗╔═╗╦═╗
║║║║ ║╠╦╝ ║║  ╠═╝║╣ ╠╦╝║║║║ ║ ║ ║╣ ╠╦╝
╚╩╝╚═╝╩╚══╩╝  ╩  ╚═╝╩╚═╩ ╩╚═╝ ╩ ╚═╝╩╚═

DESCRIPTION
******************************************************************************************
Write a program which remixes the letters of a word to determine all valid subwords.


INPUT SPECIFICATION
******************************************************************************************
There are two input files:

"words.txt" contains a list of words. Each word is to be remixed to determine
all valid subwords.

"dictionary.txt" contains the complete list of words from the Scrabble
Dictionary.


OUTPUT SPECIFICATION
******************************************************************************************
Output a file named "output.txt" which exactly matches the file "sample-output.txt".


PERMITTED .NET CLASSES
******************************************************************************************
System.Console
System.IO.StreamReader
System.IO.StreamWriter
System.Collections.Generic.List