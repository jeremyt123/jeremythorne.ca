﻿ _______  _______  _______  _______         __    _    _______  _______  __    _  __   __  _______  ______    _______  _______  ______   
|  _    ||   _   ||       ||       |       |  |  | |  |       ||       ||  |  | ||  | |  ||       ||    _ |  |       ||       ||    _ |  
| |_|   ||  |_|  ||  _____||    ___| ____  |   |_| |  |       ||   _   ||   |_| ||  |_|  ||    ___||   | ||  |_     _||    ___||   | ||  
|       ||       || |_____ |   |___ |____| |       |  |       ||  | |  ||       ||       ||   |___ |   |_||_   |   |  |   |___ |   |_||_ 
|  _   | |       ||_____  ||    ___|       |  _    |  |      _||  |_|  ||  _    ||       ||    ___||    __  |  |   |  |    ___||    __  |
| |_|   ||   _   | _____| ||   |___        | | |   |  |     |_ |       || | |   | |     | |   |___ |   |  | |  |   |  |   |___ |   |  | |
|_______||__| |__||_______||_______|       |_|  |__|  |_______||_______||_|  |__|  |___|  |_______||___|  |_|  |___|  |_______||___|  |_|

DESCRIPTION
*****************************************************************************************************************************************
Write a program to convert between counting systems.  For example, it should be able to convert base-2 (binary) numbers into base-10
(decimal) numbers.  Or it should be able to convert base-16 (hexadecimal) numbers to base-8 (octal) numbers.  Or it should be able to
convert from base-3 (ternary) to base-6 (senary).  In general, it should be able to convert from any base to any other base within the 
range from base-2 to base-16.

You cannot use any .NET classes or methods to perform the counting system conversions. You must implement the algorithm yourself!


INPUT SPECIFICATION
*****************************************************************************************************************************************
There are two input files:

"character_mappings.txt" contains the hexadecimal character mappings.

Each line of "input.txt" contains the following data:
column 0 ==> the base of the input number
column 1 ==> the input number
column 2 ==> the base of the output number

NOTE: Data fields are tab delimited.


OUTPUT SPECIFICATION
*****************************************************************************************************************************************
Your output file should exactly match the "sample-output.txt" file.


PERMITTED .NET CLASSES
*****************************************************************************************************************************************
System.IO.StreamReader
System.IO.StreamWriter
System.Collections.Generic.Dictionary