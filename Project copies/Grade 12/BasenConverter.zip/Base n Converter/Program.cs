﻿// BASE N CONVERTER
// By Jeremy Thorne
// 2018-03-26
// This program takes a input of numbers, their base and a goal base and converts the number into that goal base
// Outputs the solution in the debug folder
using System;
using System.Collections.Generic;
using System.IO;

namespace base_n_converter
{
    class Program
    {
        static string[] toStringArr(string input)
        {
            //Turns the input to a string array of each seperate char/int
            char[] inputArrChar = input.ToCharArray();

            string[] inputArr = new string[inputArrChar.Length];

            for (int i = 0; i < inputArr.Length; i++)
            {
                inputArr[i] = inputArrChar[i].ToString();
            }
            return inputArr;
        }
        static string reverse(string input)
        {
            //used to reverse the output of fromBase10 because its output is reversed
            char[] inputArr = input.ToCharArray();
            string output = "";
            for (int i = inputArr.Length - 1; i >= 0; i--)
            {
                output += inputArr[i];
            }

            return output;
        }
        static string fromBase10(int input, int outputBase, Dictionary<int, string> hexToDec)
        {
            string output = "";
            //converting the number from b10 to the desired base
            while (input > 0)
            {
                output += hexToDec[input % outputBase];
                input /= outputBase;
            }
            return output;
        }
        static int toBase10(string input, int inputBase, Dictionary<string, int> decToHex)
        {

            //Turns the input to a string array of each seperate char/int
            string[] inputArr = toStringArr(input);

            //checks to see if any char in the input is a letter not a int
            for (int i = 0; i < inputArr.Length; i++)
            {
                inputArr[i] = decToHex[inputArr[i]].ToString();
            }

            int output = 0;
            int power = 1;

            for (int i = 1; i < inputArr.Length; i++)
            {
                power *= inputBase;
            }
            //converting the input number into base 10
            for (int i = 0; i < inputArr.Length; i++)
            {
                output += int.Parse(inputArr[i].ToString()) * power;

                power /= inputBase;
            }

            return output;
        }
        static void Main(string[] args)
        {
            StreamReader mappings = new StreamReader("character_mappings.txt");

            Dictionary<string, int> decToHex = new Dictionary<string, int>();
            Dictionary<int, string> hexToDec = new Dictionary<int, string>();

            while (!mappings.EndOfStream)
            {
                string[] mapping = mappings.ReadLine().Split('\t');
                decToHex.Add(mapping[0], int.Parse(mapping[1]));
                hexToDec.Add(int.Parse(mapping[1]), mapping[0]);
            }
            mappings.Close();

            StreamReader reader = new StreamReader("input.txt");
            StreamWriter writer = new StreamWriter("output.txt");
            writer.WriteLine("INPUT BASE         INPUT VALUE         OUTPUT BASE                       OUTPUT VALUE");
            writer.WriteLine("-------------------------------------------------------------------------------------");
            while (!reader.EndOfStream)
            {
                string[] rawInput = reader.ReadLine().Split('\t');

                string input = toBase10(rawInput[1], int.Parse(rawInput[0]), decToHex).ToString();
                string output = reverse(fromBase10(int.Parse(input), int.Parse(rawInput[2]), hexToDec));
                writer.WriteLine("{0, 10} {1, 19} {2, 19} {3, 34}", rawInput[0], rawInput[1], rawInput[2], output);
            }
            reader.Close();
            writer.Close();
        }
    }
}
