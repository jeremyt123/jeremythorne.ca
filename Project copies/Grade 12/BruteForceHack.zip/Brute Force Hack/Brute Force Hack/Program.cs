﻿// BRUTE FORCE HACK
// By Jeremy Thorne
// 2018-02-13
// This program takes a number, adds its even divisors, put the sum into a psuedorandom number generator to generate 33 - 126 inclusive
// The program uses the generated numbers and turns them to chars to make a strong 12 char password.
// Output is put into the debug folder
using System;
using System.IO;

namespace Brute_Force_Hack
{
    class Program
    {
        static int factorSumCalc(int input)
        {
            int sum = 0;
            //goes through each of the number up to the input to find every divisor
            for (int i = 1; i <= input; i++)
            {
                //checks to see if the number divides into the input with no remainder and that it is even
                if (input % i == 0 && i % 2 == 0)
                {
                    sum += i;
                }

            }
            return sum;
        }
        static void Main(string[] args)
        {
            //used to write the output to a file called "output.txt"
            StreamWriter writer = new StreamWriter("output.txt");
            //used to read the "input.txt" file
            StreamReader reader = new StreamReader("input.txt");

            // Runs through each of the numbers in the input 
            while (!reader.EndOfStream)
            {
                //puts the next line of the input file into the input int
                int input = int.Parse(reader.ReadLine());
                //adds the even factors of the input to create the seed
                int seed = factorSumCalc(input);

                //uses the see to declare a new random
                Random rand = new Random(seed);

                //writes out 12 chars that make up the password
                for (int l = 0; l < 12; l++)
                {
                    writer.Write((char)rand.Next(33, 127));
                }

                writer.WriteLine();
            }
            writer.Close();
            reader.Close();
        }
    }
}
