﻿    ____  ____  __  ______________   __________  ____  ____________   __  _____   ________ __
   / __ )/ __ \/ / / /_  __/ ____/  / ____/ __ \/ __ \/ ____/ ____/  / / / /   | / ____/ //_/
  / __  / /_/ / / / / / / / __/    / /_  / / / / /_/ / /   / __/    / /_/ / /| |/ /   / ,<   
 / /_/ / _, _/ /_/ / / / / /___   / __/ / /_/ / _, _/ /___/ /___   / __  / ___ / /___/ /| |  
/_____/_/ |_|\____/ /_/ /_____/  /_/    \____/_/ |_|\____/_____/  /_/ /_/_/  |_\____/_/ |_|  
                                                                                             

DESCRIPTION
**********************************************************************************************
You have been hired by CSIS as a "white hat". A foreign spy has been transmitting sensitive
Canadian military data using a sophisticated encryption system. You have intercepted a list of 
50 large numbers. Finding the sum of the positive divisors of each number will give a random 
seed which is then used by a pseudorandom number generator to generate a 12-digit strong password.  
Each password is composed of alphanumeric and non-alphanumeric characters, ranging from ! to ~
(upper and lower bounds inclusive) on the ASCII table.  It is your job to reverse engineer this 
highly advanced encryption and obtain these 50 passwords.


INPUT SPECIFICATION
**********************************************************************************************
The file "input.txt" contains the 50 large numbers.


OUTPUT SPECIFICATION
**********************************************************************************************
Output the passwords to a file named "output.txt" which matches the file "sample-output.txt"
exactly.


PERMITTED .NET CLASSES
**********************************************************************************************
System.Random
System.IO.StreamReader
System.IO.StreamWriter