﻿// MEDIAN CALCULATOR
// By Jeremy Thorne
// 2018-02-15
// This program takes a input of numbers from a file and calculates the median for them
// Puts the output file in the debug folder
using System;
using System.IO;

namespace Median_Calculator
{
    class Program
    {
        //method for sorting arrays called bubblesort
        static double[] bubbleSort(double[] inputArray)
        {
            double save = 0;
            //two for loops that run for the length of the array so every value can be moved multiple times
            for (int i = 0; i < inputArray.Length; i++)
            {
                for (int l = i + 1; l < inputArray.Length; l++)
                {
                    //checks if the value stored at i is greater than the value stored at l
                    if (inputArray[i] > inputArray[l])
                    {
                        //switches the two values which eventually moves all the big terms to the high end and the low terms to the bottom
                        save = inputArray[i];
                        inputArray[i] = inputArray[l];
                        inputArray[l] = save;
                    }
                }

            }


            return inputArray;
        }
        //Method for calculating median
        static double medCalc(double[] inputArray)
        {
            double median = 0;
            //formula is the array length is even
            if (inputArray.Length % 2 == 0)
            {
                median = (inputArray[inputArray.Length / 2] + inputArray[(inputArray.Length - 1) / 2]) / 2;
            }
            //formula if the array length is odd
            else
            {
                median = (inputArray[inputArray.Length / 2]);
            }

            return median;
        }
        static void Main(string[] args)
        {
            //used to read from input file and write to output file
            StreamReader reader = new StreamReader("input.txt");
            StreamWriter writer = new StreamWriter("output.txt");

            //while loop which runs while there are still lines to be calculated
            while (!reader.EndOfStream)
            {
                double median = 0;
                //reads the next line of the input file
                string rawInput = reader.ReadLine();
                //converts each line to an array by splitting at the ,'s after each number
                string[] inputArrayStr = rawInput.Split(',');

                double[] inputArrayDbl = new double[inputArrayStr.Length];
                //converts the string array into a double array
                for (int l = 0; l < inputArrayStr.Length; l++)
                {
                    inputArrayDbl[l] = double.Parse(inputArrayStr[l]);
                }
                //sorts the array from lowest to highest using bubblesort method
                inputArrayDbl = bubbleSort(inputArrayDbl);
                //uses the medCalc function and stores the output in the median double
                median = medCalc(inputArrayDbl);
                //writes the median to the output file
                writer.WriteLine(median);
            }
            writer.Close();
            reader.Close();

        }
    }
}
