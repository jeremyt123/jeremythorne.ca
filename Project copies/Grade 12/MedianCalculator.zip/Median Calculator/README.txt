﻿ ___ ___    ___  ___    ____   ____  ____          __   ____  _        __  __ __  _       ____  ______   ___   ____  
|   |   |  /  _]|   \  |    | /    ||    \        /  ] /    || |      /  ]|  |  || |     /    ||      | /   \ |    \ 
| _   _ | /  [_ |    \  |  | |  o  ||  _  |      /  / |  o  || |     /  / |  |  || |    |  o  ||      ||     ||  D  )
|  \_/  ||    _]|  D  | |  | |     ||  |  |     /  /  |     || |___ /  /  |  |  || |___ |     ||_|  |_||  O  ||    / 
|   |   ||   [_ |     | |  | |  _  ||  |  |    /   \_ |  _  ||     /   \_ |  :  ||     ||  _  |  |  |  |     ||    \ 
|   |   ||     ||     | |  | |  |  ||  |  |    \     ||  |  ||     \     ||     ||     ||  |  |  |  |  |     ||  .  \
|___|___||_____||_____||____||__|__||__|__|     \____||__|__||_____|\____| \__,_||_____||__|__|  |__|   \___/ |__|\_|
                                                                                                                     

DESCRIPTION
*********************************************************************************************************************
Write a program to calculate the medians of many sequences of numbers.


INPUT SPECIFICATION
*********************************************************************************************************************
The file "input.txt" contains the sequences of numbers.  Each line contains a separate sequence for which you must
calculate the median.


OUTPUT SPECIFICATION
*********************************************************************************************************************
Output a file called "output.txt" which contains the median for each sequence.  Your output file should match
the file "sample-output.txt" exactly.


PERMITTED .NET CLASSES
*********************************************************************************************************************
System.IO.StreamReader
System.IO.StreamWriter     
