﻿// Grid Bot
// By Jeremy Thorne
// 2018-04-9
// This program is given a grid with points and a starting position and finds the optimal paths to each position in order 0, 1, 2
// Output file is put into the debug folder
using System;
using System.IO;

namespace Grid_bot
{
    class Program
    {
        //method to find the best path to the destination
        static string pathFind(int bX, int bY, int destinationX, int destinationY)
        {
            string output = "";
            bool arrived = false;

            int leftRight = bX - destinationX;
            int upDown = bY - destinationY;

            while (!arrived)
            {

                if (leftRight < 0)
                {
                    output += "E ";
                    leftRight++;
                }

                if (leftRight > 0)
                {
                    output += "W ";
                    leftRight--;
                }

                if (upDown < 0)
                {
                    output += "S ";
                    upDown++;
                }

                if (upDown > 0)
                {
                    output += "N ";
                    upDown--;
                }

                if (leftRight == 0 && upDown == 0)
                {
                    arrived = true;
                }
            }

            return output;
        }
        static void Main(string[] args)
        {
            StreamReader reader = new StreamReader("input.txt");
            StreamWriter writer = new StreamWriter("output.txt");

            int size = int.Parse(reader.ReadLine());

            while (!reader.EndOfStream)
            {
                int zeroX = 0, zeroY = 0, oneX = 0, oneY = 0, twoX = 0, twoY = 0, bX = 0, bY = 0;

                string output = "";

                //finding coords of special points
                for (int i = 0; i < size; i++)
                {
                    char[] rawInput = reader.ReadLine().ToCharArray();

                    for (int j = 0; j < size; j++)
                    {
                        switch (rawInput[j])
                        {
                            case '0':
                                Console.WriteLine(zeroX = j);
                                Console.WriteLine(zeroY = i);
                                break;
                            case '1':
                                oneX = j;
                                oneY = i;
                                break;
                            case '2':
                                twoX = j;
                                twoY = i;
                                break;
                            case 'B':
                                Console.WriteLine(bX = j);
                                Console.WriteLine(bY = i);
                                break;
                            default:
                                break;
                        }
                    }
                }

                output += pathFind(bX, bY, zeroX, zeroY);
                output += "0 ";
                output += pathFind(zeroX, zeroY, oneX, oneY);
                output += "1 ";
                output += pathFind(oneX, oneY, twoX, twoY);
                output += "2 ";
                writer.WriteLine(output);
                //this is for skipping the blank line between grids
                reader.ReadLine();
            }
            reader.Close();
            writer.Close();

        }
    }
}
