﻿using System;
using System.IO;

namespace ThorneLib
{
    public class File
    {
        private string filePath;
        private FileMode fileMode;


        //Constructor
        public File(string filePath, FileMode mode)
        {
            this.filePath = filePath;
            this.fileMode = mode;

            //checks to see if the file actually exists
            StreamReader reader = null;
            try
            {
                reader = new StreamReader(filePath);
            }
            catch
            {
                throw new Exception("FILE NOT FOUND");
            }
            finally
            {
                reader.Close();
            }
        }

        //Public Properties
        public int NumLines
        {
            get
            {
                int lines = 0;
                StreamReader reader = null;
                try
                {
                    reader = new StreamReader(FilePath);
                    while (!reader.EndOfStream)
                    {
                        reader.ReadLine();
                        lines++;
                    }
                }
                catch (IOException)
                {
                    lines = -1;
                }
                finally
                {
                    reader.Close();
                }

                return lines;
            }
        }

        public string FilePath
        {
            get
            {
                return this.filePath;
            }
        }

        public FileMode FileMode
        {
            get
            {
                return fileMode;
            }
            set
            {
                fileMode = value;
            }

        }

        //Public Methods
        public bool Read(out string[] lines)
        {
            lines = new String[NumLines];
            int index = 0;
            StreamReader reader = null;

            try
            {
                reader = new StreamReader(filePath);

                if (fileMode != FileMode.Read)
                {
                    throw new Exception("FILEMODE IS NOT SET TO READ");
                }

                while (!reader.EndOfStream)
                {
                    lines[index] = reader.ReadLine();
                    index++;
                }
                return true;
            }
            catch (IOException)
            {
                return false;
            }
            finally
            {
                reader.Close();
            }
        }

        public bool Write(string[] lines)
        {
            StreamWriter writer = null;

            try
            {
                writer = new StreamWriter(filePath);

                if (fileMode != FileMode.Write)
                {
                    throw new Exception("FILEMODE IS NOT SET TO WRITE");
                }

                for (int i = 0; i < lines.Length; i++)
                {
                    writer.WriteLine(lines[i]);
                }

                return true;
            }
            catch (IOException)
            {
                return false;
            }
            finally
            {
                writer.Close();
            }
        }

        public bool Append(string[] lines)
        {
            StreamWriter writer = null;

            try
            {
                writer = new StreamWriter(filePath, true);

                if (fileMode != FileMode.Append)
                {
                    throw new Exception("FILEMODE IS NOT SET TO APPEND");
                }

                for (int i = 0; i < lines.Length; i++)
                {
                    writer.WriteLine(lines[i]);
                }
                return true;
            }
            catch (IOException)
            {
                return false;
            }
            finally
            {
                writer.Close();
            }
        }

        public bool Insert(string[] lines, int position)
        {

            StreamWriter writer = null;
            StreamReader reader = null;

            try
            {
                reader = new StreamReader(filePath);

                if (fileMode != FileMode.Insert)
                {
                    throw new Exception("FILEMODE IS NOT SET TO INSERT");
                }

                string[] inputFileArr = new string[filePath.Length];
                int index = 0;

                while (!reader.EndOfStream)
                {
                    inputFileArr[index] = reader.ReadLine();
                    index++;
                }
                reader.Close();

                writer = new StreamWriter(filePath);

                for (int i = 0; i < position; i++)
                {
                    writer.WriteLine(inputFileArr[i]);
                }

                for (int i = 0; i < lines.Length; i++)
                {
                    writer.WriteLine(lines[i]);
                }

                for (int i = position; i < inputFileArr.Length; i++)
                {
                    writer.WriteLine(inputFileArr[i]);
                }

                return true;

            }
            catch (IOException)
            {
                return false;
            }
            finally
            {
                writer.Close();
            }
        }
    }

    public static class ArrayOps
    {
        public static float Average(float[] array)
        {
            float average = ArrayOps.Sum(array) / array.Length;
            return average;
        }

        public static void Append(ref float[] array, float value)
        {
            ArrayOps.Insert(ref array, value, array.Length);
        }

        public static void AppendRange(ref float[] array, float[] values)
        {
            ArrayOps.InsertRange(ref array, values, array.Length);
        }

        public static bool Contains(float[] array, float value)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == value)
                {
                    return true;
                }
            }
            return false;
        }

        public static float[] Copy(float[] array, int start, int end)
        {
            float[] temp = new float[end - start];

            for (int i = start; i < end; i++)
            {
                temp[i - start] = array[i];
            }

            return temp;
        }

        public static int Find(float[] array, float value)
        {
            //set it so it returns -1 if the value is not in the array
            for (int i = 0; i < array.Length; i++)
            {
                if (value == array[i])
                {
                    return i;
                }
            }
            return -1;
        }

        public static int[] FindAll(float[] array, float value)
        {
            int[] temp = new int[array.Length];
            int amount = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (value == array[i])
                {
                    temp[amount] = i;
                    amount++;
                }
            }

            int[] output = new int[amount];

            for (int i = 0; i < amount; i++)
            {
                output[i] = temp[i];
            }
            return output;
        }

        public static float[] GetRandom(float[] array, int n, int seed)
        {
            float[] output = new float[n];

            for (int i = 0; i < output.Length; i++)
            {
                RndGen random = new RndGen(seed);
                output[i] = array[random.Next(array.Length)];
            }
            return output;
        }

        public static void Insert(ref float[] array, float value, int index)
        {
            float[] temp = new float[array.Length + 1];

            for (int i = 0; i < index; i++)
            {
                temp[i] = array[i];
            }

            temp[index] = value;

            for (int i = index; i < array.Length; i++)
            {
                temp[i + 1] = array[i];
            }

            array = new float[temp.Length];

            for (int i = 0; i < temp.Length; i++)
            {
                array[i] = temp[i];
            }
        }

        public static void InsertRange(ref float[] array, float[] values, int index)
        {
            float[] temp = new float[array.Length + values.Length];

            for (int i = 0; i < index; i++)
            {
                temp[i] = array[i];
            }

            for (int i = index; i < index + values.Length; i++)
            {
                temp[i] = values[i - index];
            }

            for (int i = index; i < array.Length; i++)
            {
                temp[i + values.Length] = array[i];
            }

            array = new float[temp.Length];

            for (int i = 0; i < temp.Length; i++)
            {
                array[i] = temp[i];
            }

        }

        public static float[] Intersect(float[] array0, float[] array1)
        {
            float[] temp = new float[array0.Length + array1.Length];

            int amount = 0;

            for (int i = 0; i < array0.Length; i++)
            {
                for (int j = 0; j < array1.Length; j++)
                {
                    if (array0[i] == array1[j] && (!ArrayOps.Contains(temp, array0[i])))
                    {
                        temp[amount] = array0[i];
                        amount++;
                    }
                }
            }

            float[] output = new float[amount];

            for (int i = 0; i < output.Length; i++)
            {
                output[i] = temp[i];
            }
            return output;
        }

        public static float Median(float[] array)
        {
            ArrayOps.Sort(ref array, SortMode.Ascending);

            float median = 0;
            if (array.Length % 2 == 0)
            {
                median = (array[array.Length / 2] + array[(array.Length - 1) / 2]) / 2;
            }
            //formula if the array length is odd
            else
            {
                median = (array[array.Length / 2]);
            }
            return median;
        }

        public static float Max(float[] array)
        {
            float max = -999999999999999999;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] > max)
                {
                    max = array[i];
                }
            }
            return max;
        }

        public static float Min(float[] array)
        {
            float min = 999999999999999999;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] < min)
                {
                    min = array[i];
                }
            }

            return min;
        }

        public static void Prepend(ref float[] array, float value)
        {
            ArrayOps.Insert(ref array, value, 0);
        }

        public static void PrependRange(ref float[] array, float[] values)
        {
            ArrayOps.InsertRange(ref array, values, 0);
        }

        public static float Remove(ref float[] array, int index)
        {
            float[] temp = new float[array.Length - 1];

            float output = array[index];

            for (int i = 0, j = 0; i < temp.Length; i++, j++)
            {
                if (i == index)
                    j++;

                temp[i] = array[j];
            }
            array = temp;

            return output;
        }

        public static float[] RemoveRange(ref float[] array, int start, int end)
        {
            int index = 0;
            for (int i = start; i <= end; i++)
            {
                ArrayOps.Remove(ref array, i - index);
                index++;
            }
            return array;
        }

        public static float[] RemoveAll(ref float[] array, float value)
        {
            int[] indexes = ArrayOps.FindAll(array, value);

            for (int i = 0; i < indexes.Length; i++)
            {
                ArrayOps.Remove(ref array, indexes[i] - i);
            }
            float[] output = new float[indexes.Length];

            for (int i = 0; i < indexes.Length; i++)
            {
                output[i] = value;
            }

            return output;
        }

        public static void Reverse(ref float[] array)
        {
            float[] temp = new float[array.Length];

            for (int i = 0; i < array.Length; i++)
            {
                temp[i] = array[i];
            }

            for (int i = 0; i < array.Length; i++)
            {
                array[i] = temp[array.Length - i - 1];
            }


        }

        public static void Sort(ref float[] array, SortMode mode)
        {
            float temp = 0;

            for (int i = 0; i < array.Length; i++)
            {
                for (int l = i + 1; l < array.Length; l++)
                {
                    if (mode == SortMode.Ascending)
                    {
                        if (array[i] > array[l])
                        {
                            temp = array[i];
                            array[i] = array[l];
                            array[l] = temp;
                        }
                    }
                    else
                    {
                        if (array[i] < array[l])
                        {
                            temp = array[i];
                            array[i] = array[l];
                            array[l] = temp;
                        }
                    }
                }
            }
        }

        public static float Sum(float[] array)
        {
            float sum = 0;

            for (int i = 0; i < array.Length; i++)
            {
                sum += array[i];
            }

            return sum;
        }

        public static float[] Union(float[] array0, float[] array1)
        {
            int[] remove = new int[array1.Length];
            int index = 0;
            for (int i = 0; i < array0.Length; i++)
            {
                for (int j = 0; j < array1.Length; j++)
                {
                    if (array0[i] == array1[j])
                    {
                        remove[index] = j;
                        index++;
                    }
                }
            }

            for (int i = 0; i < index - 1; i++)
            {
                ArrayOps.Remove(ref array1, remove[i] - i);
            }

            float[] output = new float[array1.Length + array0.Length];

            for (int i = 0; i < array0.Length; i++)
            {
                output[i] = array0[i];
            }
            for (int i = 0; i < array1.Length; i++)
            {
                output[i + array0.Length] = array1[i];
            }
            return output;
        }
    }

    public class RndGen
    {
        private int seed;

        //Constructors
        public RndGen(int seed)
        {
            this.seed = seed;
        }

        public RndGen()
        {
            DateTime time = new DateTime();
            time = DateTime.Now;
            int seed = (int)time.Millisecond;
            this.seed = seed;
        }

        //Property
        public int Seed
        {
            get
            {
                return seed;
            }
            set
            {
                seed = value;
            }
        }

        //Methods
        public int Next()
        {
            int output = Next(0, int.MaxValue);
            return output;
        }

        public int Next(int max)
        {
            int output = Next(0, max);
            return output;
        }

        public int Next(int min, int max)
        {
            int output = (seed * seed) * 32 / 5 + 99;
            bool works = false;

            while (!works)
            {
                if (output > max)
                {
                    output /= 5;
                    output -= 1;
                }

                if (output < min)
                {
                    output *= 3;
                    output += 1;
                }

                if (output < 0)
                {
                    output *= -1;
                }

                if (output >= min && output <= max)
                {
                    works = true;
                }

            }
            return output;
        }

        public float NextFloat()
        {
            float output = (((seed * seed) * 43) / 12) + 0.13f;
            bool works = false;

            while (!works)
            {

                if (output > 1.0f)
                {
                    output /= 3.1f;
                    output -= 0.025f;
                }
                if (output < 0)
                {
                    output *= -4.9f;
                    output += 0.1f;
                }
                if (output < 1 && output > 0)
                {
                    works = true;
                    continue;
                }
            }
            return output;
        }
    }
}
