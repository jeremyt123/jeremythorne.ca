 __    __     __  __        __         __     ______    
/\ "-./  \   /\ \_\ \      /\ \       /\ \   /\  == \   
\ \ \-./\ \  \ \____ \     \ \ \____  \ \ \  \ \  __<   
 \ \_\ \ \_\  \/\_____\     \ \_____\  \ \_\  \ \_____\ 
  \/_/  \/_/   \/_____/      \/_____/   \/_/   \/_____/ 
                                                                                                                                                                                                                                           

DESCRIPTION
******************************************************************************************************************
Create your own library of modular, reusable code.  Your library will be contained in the MyLib namespace (or another
suitable namespace) and will include the custom classes: File, ArrayOps, and RndGen.  Each class will contain useful 
properties and methods. Watch the video at https://goo.gl/smkEb8 to get started.

Here are the specifications for each class:

NAMESPACE: MyLib	

File (public, non-static, IO wrapper class [https://goo.gl/W59Us6])

	DESCRIPTION:	

		The File class handles basic file IO operations and is a wrapper class for the .NET IO classes.

	CONSTRUCTOR [https://goo.gl/2ALYSx]:

		Description: Requires the path to the file and the file mode before instantiating the File object.
		Signature: public File(string filePath, FileMode mode)
		Arg 0: The path to a file.
		Arg 1: The file mode of the File object (read, write, append, or insert).  Implements an enum.
		Exception: Throws a custom IO exception if the file is not found.

	PUBLIC PROPERTIES [https://goo.gl/3jW82S]:

		NumLines
			Description: Gets the number of lines in the file or -1 if there is an IOException. [https://goo.gl/KMWsa6]
			Access: Can be viewed only.  
		
		FilePath
			Description: Path to the file.
			Access: Can be viewed only.
		
		Mode
			Description: File IO mode of the File object. 
			Access: Can be viewed or changed.
				
	PUBLIC METHODS [https://goo.gl/hV3ztD]:

		Read
			Description: Loads contents of a file into an array.
			Signature: public bool Read(out string[] lines)
			Arg 0: An array to be filled with the contents of the file. [https://goo.gl/dJS9RU]
			Return: Returns true if the operation was successful and false if there was an IOException. 
			Exceptions: Throws an exception if file mode is not set to read. [https://goo.gl/yn5w8J]

		Write
			Description: Writes contents of an array to a file.
			Signature: public bool Write(string[] lines)
			Arg 0: A string array whose contents are written to a new file.
			Return: Returns true if the operation was successful and false if there was an IOException.
			Exceptions: Throws an exception if file mode is not set to write.

		Append
			Description: Appends contents of an array to a file.
			Signature: public bool Append(string[] lines)
			Arg 0: A string array whose contents are appended to the file.
			Return: Returns true if the operation was successful and false if there was an IOException.
			Exceptions: Throws an exception if file mode is not set to append.

		Insert
			Description: Inserts contents of an array into a file at a specified location.
			Signature: public bool Insert(string[] lines, int position) 
			Arg 0: A string array whose contents are inserted into the file at a specified location.
			Arg 1: The position (line number) at which the new lines should be inserted.
			Return: Returns true if the operation was successful and false if there was an IOException.
			Exceptions: Throws an exception if file mode is not set to insert.
	
	PERMITTED .NET METHODS:
		System.IO.StreamReader.ReadLine
		System.IO.StreamWriter.WriteLine


ArrayOps (public static class) [https://goo.gl/fRmzQd]

	DESCRIPTION: 

		The ArrayOps class handles basic array operations.
		
	PUBLIC METHODS:

		Average
			Description: Computes the average of the elements of an array.
			Signature: public static float Average(float[] array)
			Arg 0: The array.
			Return: The average.
		
		Append
			Description: Adds a value to the end of an array.
			Signature: public static void Append(ref float[] array, float value) [https://goo.gl/oYqWgz]
			Arg 0: The array, passed by reference.
			Arg 1: The value to append.

		AppendRange
			Description: Add a range of values to the end of an array.
			Signature: public static void AppendRange(ref float[] array, float[] values)
			Arg 0: The array, passed by reference.
			Arg 1: The values to append.
		
		Contains
			Description: Determines whether a given value appears in an array.
			Signature: public static bool Contains(float[] array, float value)
			Arg 0: The array.
			Arg 1: The value to search for.
			Return: bool indicating whether the specified value is in the array.
		
		Copy
			Description: Copies an array, in whole or in part, to a new array.
			Signature: public static float[] Copy(float[] array, int start, int end)
			Arg 0: The array.
			Arg 1: The inclusive index to start at.
			Arg 2: The exclusive index to end at.
			Return: The new array.

		Find
			Description: Returns the first index of the specified value in the array.
			Signature: public static int Find(float[] array, float value)
			Arg 0: The array.
			Arg 1: The value.
			Return: The first index of the value.
		
		FindAll
			Description: Returns the indices all elements in an array with the specified value.
			Signature: public static int[] FindAll(float[] array, float value)
			Arg 0: The array.
			Arg 1: The value.
			Return: An array containing the indices of all instances of the value.
		
		GetRandom
			Description: Returns a random sequence of elements from the array.
			Signature: public static float[] GetRandom(float[] array, int n, int seed)
			Arg 0: The array.
			Arg 1: The number of random elements to return.
			Arg 2: The seed for pseudorandom number generation.
			Return: An array of random elements from the original array.
		
		Insert
			Description: Inserts a value into an array at a specified index.  Shifts existing elements.
			Signature: public static void Insert(ref float[] array, float value, int index)
			Arg 0: The array, passed by reference.
			Arg 1: The value to be inserted.
			Arg 2: The index where the value is inserted.
		
		InsertRange
			Description: Inserts a range of values into an array at a specified point.  Shifts existing elements.
			Signature: public static void InsertRange(ref float[] array, float[] values, int index)
			Arg 0: The array, passed be reference.
			Arg 1: The values to be inserted.
			Arg 2: The inex where the values are inserted.
		
		Intersect
			Description: Returns an array composed of the elements in common between two arrays, with no duplicates.
			Signature: public static float[] Intersect(float[] array0, float[] array1)
			Arg 0: The first array.
			Arg 1: The second array.
			Return: An array containing all elements which are contained in both arrays, with no duplicates.
		
		Median
			Description: Returns the median of the values in an array.
			Signature: public static float Mean(float[] array)
			Arg 0: The array.
			Arg 1: The mean of the values in the array.
		
		Max
			Description: Returns the maximum value in an array.
			Signature: public static float Max(float[] array)
			Arg 0: The array.
			Return: The maximum value in the array.
		
		Min
			Description: Returns the minimum value in an array.
			Signature: public static float Min(float[] array)
			Arg 0: The array.
			Return: The minimum value in the array.
						
		Prepend
			Description: Adds a value to the start of an array.  Shifts elements.
			Signature: public static void Prepend(ref float[] array, float value)
			Arg 0: The array, passed by reference.
			Arg 1: The value to be prepended.

		PrependRange
			Description:  Adds a range of value to the start of an array.  Shifts elements.
			Signature: public static void PrependRange(ref float[] array, float[] values)
			Arg 0: The array, passed by reference.
			Arg 1: The values to be prepended.
		
		Remove
			Description: Removes and returns an element from an array at the specified index.  Shifts remaining elements.
			Signature: public static float Remove(ref float[] array, int index)
			Arg 0: The array, passed by reference.
			Arg 1: The index of the element to be removed.

		RemoveRange
			Description: Removes and returns elements of an array in the specified index range.  Shifts remaining elements.
			Signature: public static float[] RemoveRange(ref float[] array, int start, int end)
			Arg 0: The array, passed by reference.
			Arg 1: The inclusive starting index.
			Arg 2: The exclusive final index.
		
		RemoveAll
			Description: Removes and returns all elements with the specified value from the array.  Shifts remaining elements.
			Signature: public static float[] RemoveAll(ref float[] array, float value)
			Arg 0: The array, passed by reference.
			Arg 1: The value to be removed from the array.
		
		Reverse
			Description: Reverses an array.
			Signature: public static void Reverse(ref float[] array)
			Arg 0: The array, passed by reference.
		
		Sort
			Description: Sorts an array in either ascending or descending order.
			Signature: public static void Sort(ref float[] array, SortMode mode)
			Arg 0: The array, passed by reference.
			Arg 1: The sorting mode (ascending or descending).
		
		Sum
			Description: Returns the sum of the elements in an array.
			Signature: public static float Sum(float[] array)
			Arg 0: The array.
			Return: The sum of the values in the array.
				
		Union
			Description: Returns an array containing the elements in both arrays, without duplicates.
			Signature: public static float[] Union(float[] array0, float[] array1)
			Arg 0: The first array.
			Arg 1: The second array.
			Return: An array containing the elements in both arrays, without duplicates.

	PERMITTED .NET METHODS: none


RndGen (public, non-static class)

	DESCRIPTION:
	
		The RndGen class is a random number generator that uses the VonNeumann algorithm [https://goo.gl/iJ9TGT].
		
	CONSTRUCTOR (1ST OVERLOAD):
		Description: This overload accepts a random seed for the pseudorandom number generator.
		Signature: RndGen(int seed)
		Arg 0: The seed for the pseudorandom number generator.

	CONSTRUCTOR (2ND OVERLOAD):
		Description: This overload accepts no random seed and just uses the system time as the seed.
		Signature: RndGen()

	PUBLIC PROPERTIES:

		Seed
			Description: The seed number used for the pseudorandom number generator.
			Access: Can be viewed or changed.

	PUBLIC METHODS:

		Next
			Description: Returns a non-negative random integer between 0 and int.MaxValue.
			Signature: public int Next()
			Return: A non-negative random intenger.

		Next
			Description: Returns a random integer between 0 and a specified exclusive upper bound.
			Signature: public int Next(int max)
			Return: A random integer between 0 and the specified upper exclusive bound.

		Next
			Description: Returns a random integer between the specified inclusive lower and exclusive upper bound.
			Signature: public int Next(int min, int max)
			Return: A random integer between the specified minimum and maximum values.

		NextFloat
			Description: Returns a random float between 0.0 and 1.0.
			Signature: public float NextFloat()
			Return: A random float between 0.0 (inclusive) and 1.0 (inclusive).

	PERMITTED .NET METHODS: none